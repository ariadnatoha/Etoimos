//
//  Apunt+CoreDataProperties.h
//  ÉtoimosApp
//
//  Created by Miquel Perera on 27/7/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Apunt+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Apunt (CoreDataProperties)

+ (NSFetchRequest<Apunt *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSDate *dataCreacio;
@property (nullable, nonatomic, copy) NSDate *dataModificacio;
@property (nullable, nonatomic, copy) NSString *assignatura;
@property (nullable, nonatomic, copy) NSString *tema;
@property (nullable, nonatomic, retain) NSData *imatge;
@property (nullable, nonatomic, copy) NSString *nom;

@end

NS_ASSUME_NONNULL_END
