//
//  Apunt+CoreDataProperties.m
//  ÉtoimosApp
//
//  Created by Miquel Perera on 27/7/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Apunt+CoreDataProperties.h"

@implementation Apunt (CoreDataProperties)

+ (NSFetchRequest<Apunt *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Apunt"];
}

@dynamic dataCreacio;
@dynamic dataModificacio;
@dynamic assignatura;
@dynamic tema;
@dynamic imatge;
@dynamic nom;

@end
