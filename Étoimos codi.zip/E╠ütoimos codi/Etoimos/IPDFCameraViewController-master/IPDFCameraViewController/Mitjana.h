//
//  Mitjana.h
//  ÉtoimosApp
//
//  Created by Miquel Perera on 28/6/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Mitjana:UIViewController <UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *taulaApunts;
@property (nonatomic,retain) NSMutableArray*arrayAssignatures;
@property (nonatomic,retain) NSMutableArray*arrayMitjanes;
@property (nonatomic,retain) NSString*assignaturaSel;
@property int comptadoAmbMitjana;
@property float sumaNotes;

@end
