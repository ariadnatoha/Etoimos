//
//  Mitjana.m
//  ÉtoimosApp
//
//  Created by Miquel Perera on 28/6/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Mitjana.h"
#import "detallMitjana.h"

@interface Mitjana ()

@end

@implementation Mitjana
@synthesize taulaApunts,arrayAssignatures,assignaturaSel,arrayMitjanes,comptadoAmbMitjana,sumaNotes;

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.arrayAssignatures=[[NSMutableArray alloc] init];
    self.arrayMitjanes=[[NSMutableArray alloc] init];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    if ([defaults3vc objectForKey:@"Mitjanes"] !=nil) {
        self.arrayMitjanes = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Mitjanes"]];
    }
    if ([defaults3vc objectForKey:@"Assignatures"] ==nil) {
        NSArray*assignatura1=[[NSArray alloc]initWithObjects:@"Filosofia", @"Presentació inicial", nil];
        NSArray*assignatura2=[[NSArray alloc]initWithObjects:@"Català", @"Presentació inicial", nil];
        NSArray*assignatura3=[[NSArray alloc]initWithObjects:@"Castellà", @"Presentació inicial", nil];
        [self.arrayAssignatures addObject:assignatura1];
        [self.arrayAssignatures addObject:assignatura2];
        [self.arrayAssignatures addObject:assignatura3];
        [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
        [defaults3vc synchronize];
        NSLog(@"Creem l'array");
    }else{
        self.arrayAssignatures = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Assignatures"]];
        if (self.arrayMitjanes.count > 0 && self.arrayAssignatures.count > 0) {
            self.comptadoAmbMitjana=0;
            self.sumaNotes=0;
            for (int f =0; f<self.arrayAssignatures.count; f++) {
                NSArray*assig2=[self.arrayAssignatures objectAtIndex:f];
                BOOL trobat2 = NO;
                float mitjana3 = 0;
                for (int k=0; k<self.arrayMitjanes.count; k++) {
                    NSDictionary*valorMitjanes3=[self.arrayMitjanes objectAtIndex:k];
                    if ([[valorMitjanes3 objectForKey:@"nomMitjana"] isEqualToString:[assig2 objectAtIndex:0]]) {
                        trobat2=YES;
                        float valor13 = [[valorMitjanes3 objectForKey:@"valor1"] floatValue];
                        float pond13 = [[valorMitjanes3 objectForKey:@"pond1"] floatValue];
                        float valor23 = [[valorMitjanes3 objectForKey:@"valor2"] floatValue];
                        float pond23 = [[valorMitjanes3 objectForKey:@"pond2"] floatValue];
                        float valor33 = [[valorMitjanes3 objectForKey:@"valor3"] floatValue];
                        float pond33 = [[valorMitjanes3 objectForKey:@"pond3"] floatValue];
                        float actitud13=[[valorMitjanes3 objectForKey:@"actitud1"] floatValue];
                        float pondActitud13=[[valorMitjanes3 objectForKey:@"pondActitud1"] floatValue];
                        float notaAltresExamens13=[[valorMitjanes3 objectForKey:@"notaAltresExamens1"] floatValue];
                        float pondAltresExamens13=[[valorMitjanes3 objectForKey:@"pondAltresExamens1"] floatValue];
                        float notaAltresExamens23=[[valorMitjanes3 objectForKey:@"notaAltresExamens2"] floatValue];
                        float pondAltresExamens23=[[valorMitjanes3 objectForKey:@"pondAltresExamens2"] floatValue];
                        float notaExercicis13=[[valorMitjanes3 objectForKey:@"notaExercicis11"] floatValue];
                        float pondExercicis13=[[valorMitjanes3 objectForKey:@"pondExercicis1"] floatValue];
                        float notaExercicis23=[[valorMitjanes3 objectForKey:@"notaExercicis2"] floatValue];
                        float pondExercicis23=[[valorMitjanes3 objectForKey:@"pondExercicis2"] floatValue];
                        int comptadorValors3=0;
                        int control1= 0;
                        int control2= 0;
                        int control3= 0;
                        int control4= 0;
                        int control5= 0;
                        int control6= 0;
                        int control7= 0;
                        int control8= 0;
                        if (valor13*pond13 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control1= 1;
                        }
                        if (valor23*pond23 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control2= 1;
                        }
                        if (valor33*pond33 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control3= 1;
                        }
                        if (actitud13*pondActitud13 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control4= 1;
                        }
                        if (notaAltresExamens13*pondAltresExamens13 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control5= 1;
                        }
                        if (notaAltresExamens23*pondAltresExamens23 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control6= 1;
                        }
                        if (notaExercicis13*pondExercicis13 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control7= 1;
                        }
                        if (notaExercicis23*pondExercicis23 !=0) {
                            comptadorValors3=comptadorValors3+1;
                            control8= 1;
                        }
                        if (comptadorValors3 > 0) {
                            mitjana3 = ((valor13*pond13) + (valor23*pond23) + (valor33*pond33) + (actitud13*pondActitud13) + (notaAltresExamens13*pondAltresExamens13) + (notaAltresExamens23*pondAltresExamens23) + (notaExercicis13*pondExercicis13) + (notaExercicis23*pondExercicis23)) / (pond13*control1 + pond23*control2 + pond33*control3 + pondActitud13*control4 + pondAltresExamens13*control5 + pondAltresExamens23*control6 + pondExercicis13*control7 + pondExercicis23*control8);
                            
                            self.comptadoAmbMitjana=self.comptadoAmbMitjana+1;
                            self.sumaNotes=self.sumaNotes+mitjana3;
                            NSLog(@"%@%d",@"Mitjanes robades: ",self.comptadoAmbMitjana);
                            NSLog(@"%@%f",[assig2 objectAtIndex:0],mitjana3);
                        }
                    }
                }
            }
        }
    }
    [self.taulaApunts reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView{
    if (self.comptadoAmbMitjana>0) {
        return 2;
    }else{
        return 1;
    }
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==1) {
        return 2;
    }else{
        return self.arrayAssignatures.count;
    }
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString*CellIdentifier=@"Cell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    NSString*texteMostrar=@"";
    cell.detailTextLabel.text=@"";
    if (indexPath.section==1) {
        if (indexPath.row==1) {
            cell.textLabel.font=[UIFont fontWithName:@"TrebuchetMS-Bold" size:24];
            cell.textLabel.text=@"Mitjana total";
            cell.detailTextLabel.font=[UIFont fontWithName:@"TrebuchetMS-Bold" size:22];
            cell.detailTextLabel.text=[NSString stringWithFormat:@"%.2f",self.sumaNotes/self.comptadoAmbMitjana];
        }else{
            cell.textLabel.text=@"";
        }
    }else{
        NSArray*assig=[self.arrayAssignatures objectAtIndex:indexPath.row];
        if ([self.arrayMitjanes count] ==0 ) {
            texteMostrar=[assig objectAtIndex:0];
        }else{
            BOOL trobat = NO;
            float mitjana = 0;
            for (int k=0; k<self.arrayMitjanes.count; k++) {
                NSDictionary*valorMitjanes=[self.arrayMitjanes objectAtIndex:k];
                if ([[valorMitjanes objectForKey:@"nomMitjana"] isEqualToString:[assig objectAtIndex:0]]) {
                    trobat = YES;
                    float valor1 = [[valorMitjanes objectForKey:@"valor1"] floatValue];
                    float pond1 = [[valorMitjanes objectForKey:@"pond1"] floatValue];
                    float valor2 = [[valorMitjanes objectForKey:@"valor2"] floatValue];
                    float pond2 = [[valorMitjanes objectForKey:@"pond2"] floatValue];
                    float valor3 = [[valorMitjanes objectForKey:@"valor3"] floatValue];
                    float pond3 = [[valorMitjanes objectForKey:@"pond3"] floatValue];
                    float actitud1=[[valorMitjanes objectForKey:@"actitud1"] floatValue];
                    float pondActitud1=[[valorMitjanes objectForKey:@"pondActitud1"] floatValue];
                    float notaAltresExamens1=[[valorMitjanes objectForKey:@"notaAltresExamens1"] floatValue];
                    float pondAltresExamens1=[[valorMitjanes objectForKey:@"pondAltresExamens1"] floatValue];
                    float notaAltresExamens2=[[valorMitjanes objectForKey:@"notaAltresExamens2"] floatValue];
                    float pondAltresExamens2=[[valorMitjanes objectForKey:@"pondAltresExamens2"] floatValue];
                    float notaExercicis1=[[valorMitjanes objectForKey:@"notaExercicis11"] floatValue];
                    float pondExercicis1=[[valorMitjanes objectForKey:@"pondExercicis1"] floatValue];
                    float notaExercicis2=[[valorMitjanes objectForKey:@"notaExercicis2"] floatValue];
                    float pondExercicis2=[[valorMitjanes objectForKey:@"pondExercicis2"] floatValue];
                    int comptadorValors=0;
                    int control1= 0;
                    int control2= 0;
                    int control3= 0;
                    int control4= 0;
                    int control5= 0;
                    int control6= 0;
                    int control7= 0;
                    int control8= 0;
                    if (valor1*pond1 !=0) {
                        comptadorValors=comptadorValors+1;
                        control1= 1;
                    }
                    if (valor2*pond2 !=0) {
                        comptadorValors=comptadorValors+1;
                        control2= 1;
                    }
                    if (valor3*pond3 !=0) {
                        comptadorValors=comptadorValors+1;
                        control3= 1;
                    }
                    if (actitud1*pondActitud1 !=0) {
                        comptadorValors=comptadorValors+1;
                        control4= 1;
                    }
                    if (notaAltresExamens1*pondAltresExamens1 !=0) {
                        comptadorValors=comptadorValors+1;
                        control5= 1;
                    }
                    if (notaAltresExamens2*pondAltresExamens2 !=0) {
                        comptadorValors=comptadorValors+1;
                        control6= 1;
                    }
                    if (notaExercicis1*pondExercicis1 !=0) {
                        comptadorValors=comptadorValors+1;
                        control7= 1;
                    }
                    if (notaExercicis2*pondExercicis2 !=0) {
                        comptadorValors=comptadorValors+1;
                        control8= 1;
                    }
                    if (comptadorValors > 0) {
                        mitjana = ((valor1*pond1) + (valor2*pond2) + (valor3*pond3) + (actitud1*pondActitud1) + (notaAltresExamens1*pondAltresExamens1) + (notaAltresExamens2*pondAltresExamens2) + (notaExercicis1*pondExercicis1) + (notaExercicis2*pondExercicis2)) / (pond1*control1 + pond2*control2 + pond3*control3 + pondActitud1*control4 + pondAltresExamens1*control5 + pondAltresExamens2*control6 + pondExercicis1*control7 + pondExercicis2*control8);
                    }
                }
            }
            texteMostrar=[assig objectAtIndex:0];
            if (trobat && mitjana != 0) {
                cell.detailTextLabel.text=[NSString stringWithFormat:@"%.2f",mitjana];
            }
        }
        cell.textLabel.text=texteMostrar;
    }
    return cell;
}

-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0) {
        NSArray*assig=[self.arrayAssignatures objectAtIndex:indexPath.row];
        self.assignaturaSel=[assig objectAtIndex:0];
        [self performSegueWithIdentifier:@"anarDetall" sender:self];
    }
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"anarDetall"]){
        [[segue destinationViewController] setAssigMitg:self.assignaturaSel];
    }
}

@end
