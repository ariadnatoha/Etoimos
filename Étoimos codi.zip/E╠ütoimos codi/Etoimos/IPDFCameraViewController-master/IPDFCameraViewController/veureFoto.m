//
//  veureFoto.m
//  Étoimos
//
//  Created by Miquel Perera on 2/9/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "veureFoto.h"
#import <AudioToolbox/AudioToolbox.h>

@interface veureFoto ()

@end

@implementation veureFoto

@synthesize scrollView, imageView, imatgeRebuda;

-(void)viewDidLoad{
    [super viewDidLoad];
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(orientationChanged:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
    if (([[[UIDevice currentDevice] systemVersion] floatValue] < 8) && UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)){
        scrollView.maximumZoomScale=10.0;
        scrollView.minimumZoomScale=1;
        scrollView.clipsToBounds=YES;
        scrollView.delegate=self;
        scrollView.backgroundColor=[UIColor blackColor];
        scrollView.indicatorStyle=UIScrollViewIndicatorStyleWhite;
        UIImageView*tempImageView=[[UIImageView alloc] initWithImage:imatgeRebuda];
        self.imageView=tempImageView;
        [imageView setFrame:CGRectMake(0,0,480,320)];
        imageView.userInteractionEnabled=YES;
        self.scrollView.zoomScale=1;
        imageView.contentMode=UIViewContentModeCenter;
        imageView.contentMode=UIViewContentModeScaleAspectFit;
        UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dobleToc:)];
        tap.numberOfTapsRequired=2;
        tap.numberOfTouchesRequired=1;
        [imageView addGestureRecognizer:tap];
        UILongPressGestureRecognizer*recognizer=[[UILongPressGestureRecognizer alloc ] initWithTarget:self action:@selector(menu:)];
        recognizer.minimumPressDuration=0.2;
        [imageView addGestureRecognizer:recognizer];
        [scrollView addSubview:imageView];
    }else{
        UIImageView*tempImageView=[[UIImageView alloc] initWithImage:imatgeRebuda];
        self.imageView =tempImageView;
        scrollView.maximumZoomScale=10.0;
        scrollView.minimumZoomScale=1;
        scrollView.clipsToBounds=YES;
        scrollView.delegate=self;
        scrollView.backgroundColor=[UIColor blackColor];
        scrollView.indicatorStyle=UIScrollViewIndicatorStyleWhite;
        [imageView setFrame:self.view.frame];
        imageView.userInteractionEnabled=YES;
        imageView.contentMode=UIViewContentModeCenter;
        imageView.contentMode=UIViewContentModeScaleAspectFit;
        UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dobleToc:)];
        tap.numberOfTapsRequired=2;
        tap.numberOfTouchesRequired=1;
        [imageView addGestureRecognizer:tap];
        UILongPressGestureRecognizer*recognizer=[[UILongPressGestureRecognizer alloc ] initWithTarget:self action:@selector(menu:)];
        recognizer.minimumPressDuration=0.2;
        [imageView addGestureRecognizer:recognizer];
        [scrollView addSubview:imageView];
    }
}

-(void)menu:(id)sender{
    AudioServicesPlaySystemSound(0x450);
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)dobleToc:(id)sender{
    CGFloat zoomScale=scrollView.zoomScale;
    if (zoomScale == 1.0){
        [self dismissViewControllerAnimated:YES completion:nil];
    }else{
        if (([[[UIDevice currentDevice] systemVersion] floatValue] < 8) &&  UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)){
            [imageView removeFromSuperview];
            UIImageView*tempImageView=[[UIImageView alloc] initWithImage:imatgeRebuda];
            self.imageView=tempImageView;
            [imageView setFrame:CGRectMake(0,0,480,320)];
            imageView.userInteractionEnabled=YES;
            self.scrollView.zoomScale=1;
            imageView.contentMode=UIViewContentModeCenter;
            imageView.contentMode=UIViewContentModeScaleAspectFit;
            UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dobleToc:)];
            tap.numberOfTapsRequired=2;
            tap.numberOfTouchesRequired=1;
            [imageView addGestureRecognizer:tap];
            UILongPressGestureRecognizer*recognizer=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(menu:)];
            recognizer.minimumPressDuration=0.2;
            [imageView addGestureRecognizer:recognizer];
            [scrollView addSubview:imageView];
        }else{
            [imageView removeFromSuperview];
            UIImageView*tempImageView=[[UIImageView alloc] initWithImage:imatgeRebuda];
            self.imageView =tempImageView;
            [imageView setFrame:self.view.frame];
            imageView.userInteractionEnabled=YES;
            scrollView.clipsToBounds=YES;
            self.scrollView.zoomScale=1.0;
            imageView.contentMode=UIViewContentModeCenter;
            imageView.contentMode=UIViewContentModeScaleAspectFit;
            UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dobleToc:)];
            tap.numberOfTapsRequired=2;
            tap.numberOfTouchesRequired=1;
            [imageView addGestureRecognizer:tap];
            UILongPressGestureRecognizer*recognizer=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(menu:)];
            recognizer.minimumPressDuration=0.2;
            [imageView addGestureRecognizer:recognizer];
            [scrollView addSubview:imageView];
        }
    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(orientationChanged:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.imatgeRebuda=nil;
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

-(void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

-(UIView*)viewForZoomingInScrollView:(UIScrollView*)scrollView{
    return imageView;
}

-(void)orientationChanged:(NSNotification*)notification{
    if (([[[UIDevice currentDevice] systemVersion] floatValue] < 8) &&  UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)){
        [imageView removeFromSuperview];
        UIImageView*tempImageView=[[UIImageView alloc] initWithImage:imatgeRebuda];
        self.imageView =tempImageView;
        [imageView setFrame:CGRectMake(0,0,480,320)];
        imageView.userInteractionEnabled=YES;
        self.scrollView.zoomScale=1;
        imageView.contentMode=UIViewContentModeCenter;
        imageView.contentMode=UIViewContentModeScaleAspectFit;
        UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dobleToc:)];
        tap.numberOfTapsRequired=2;
        tap.numberOfTouchesRequired=1;
        [imageView addGestureRecognizer:tap];
        UILongPressGestureRecognizer*recognizer=[[UILongPressGestureRecognizer alloc ] initWithTarget:self action:@selector(menu:)];
        recognizer.minimumPressDuration=0.2;
        [imageView addGestureRecognizer:recognizer];
        [scrollView addSubview:imageView];
    }else{
        [imageView removeFromSuperview];
        UIImageView*tempImageView=[[UIImageView alloc] initWithImage:imatgeRebuda];
        self.imageView =tempImageView;
        [imageView setFrame:self.view.frame];
        imageView.userInteractionEnabled=YES;
        self.scrollView.zoomScale=1.0;
        imageView.contentMode=UIViewContentModeCenter;
        imageView.contentMode=UIViewContentModeScaleAspectFit;
        UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dobleToc:)];
        tap.numberOfTapsRequired=2;
        tap.numberOfTouchesRequired=1;
        [imageView addGestureRecognizer:tap];
        UILongPressGestureRecognizer*recognizer=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(menu:)];
        recognizer.minimumPressDuration=0.2;
        [imageView addGestureRecognizer:recognizer];
        [scrollView addSubview:imageView];
    }
}

@end
