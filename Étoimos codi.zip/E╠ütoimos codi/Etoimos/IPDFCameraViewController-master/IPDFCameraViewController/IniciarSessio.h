//
//  IniciarSessio.h
//  ÉtoimosApp
//
//  Created by Miquel Perera on 2/7/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IniciarSessio : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *Usuari;
@property (weak, nonatomic) IBOutlet UITextField *Clau;

@property (nonatomic, retain) NSString *Usuari2;
@property (nonatomic, retain) NSString *Clau2;
@property (nonatomic, retain) NSString *Resposta;

- (IBAction)Comença:(id)sender;

@end
