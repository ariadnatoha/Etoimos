//
//  AppDelegate.m
//  IPDFCameraViewController
//
//  Created by Maximilian Mackh on 11/01/15.
//  Copyright (c) 2015 Maximilian Mackh. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    UITabBarController*tabb=(UITabBarController*)self.window.rootViewController;
    //tabb.selectedIndex=2;
    UITabBar*tabBar=tabb.tabBar;
    UITabBarItem*tabBarItem1=[tabBar.items objectAtIndex:0];
    UITabBarItem*tabBarItem2=[tabBar.items objectAtIndex:1];
    UITabBarItem*tabBarItem3=[tabBar.items objectAtIndex:2];
    UITabBarItem*tabBarItem4=[tabBar.items objectAtIndex:3];
    UITabBarItem*tabBarItem5=[tabBar.items objectAtIndex:4];
    //UITabBarItem*tabBarItem6=[tabBar.items objectAtIndex:5];
    [tabBarItem1 setImage:[UIImage imageNamed:@"icons8-Calendar-50.png"]];
    [tabBarItem2 setImage:[UIImage imageNamed:@"icons8-Books-50.png"]];
    [tabBarItem3 setImage:[UIImage imageNamed:@"icons8-Camera-50.png"]];
    [tabBarItem4 setImage:[UIImage imageNamed:@"icons8-Student Male-50.png"]];
    [tabBarItem5 setImage:[UIImage imageNamed:@"icons8-Calculator-50.png"]];
    //[tabBarItem6 setImage:[UIImage imageNamed:@"ajustes.png"]];
    
    return YES;
}

-(void)applicationWillTerminate:(UIApplication*)application{
    [self saveContext];
}

#pragma mark - Core Data stack
@synthesize managedObjectContext=_managedObjectContext;
@synthesize managedObjectModel=_managedObjectModel;
@synthesize persistentStoreCoordinator=_persistentStoreCoordinator;

-(NSURL*)applicationDocumentsDirectory{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

-(NSManagedObjectModel*)managedObjectModel{
    if (_managedObjectModel != nil){
        return _managedObjectModel;
    }
    NSURL*modelURL=[[NSBundle mainBundle] URLForResource:@"Model" withExtension:@"momd"];
    _managedObjectModel=[[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

-(NSPersistentStoreCoordinator*)persistentStoreCoordinator{
    if (_persistentStoreCoordinator != nil){
        return _persistentStoreCoordinator;
    }
    _persistentStoreCoordinator=[[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    NSURL*storeURL=[[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"Model.sqlite"];
    NSError*error=nil;
    NSString *failureReason = @"There was an error creating or loading the application's saved data.";
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]){
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[NSLocalizedDescriptionKey] = @"Failed to initialize the application's saved data";
        dict[NSLocalizedFailureReasonErrorKey] = failureReason;
        dict[NSUnderlyingErrorKey] = error;
        error = [NSError errorWithDomain:@"YOUR_ERROR_DOMAIN" code:9999 userInfo:dict];
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    return _persistentStoreCoordinator;
}

- (NSManagedObjectContext *)managedObjectContext {
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (!coordinator) {
        return nil;
    }
    _managedObjectContext = [[NSManagedObjectContext alloc] init];
    [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    return _managedObjectContext;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        NSError *error = nil;
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }
}

@end
