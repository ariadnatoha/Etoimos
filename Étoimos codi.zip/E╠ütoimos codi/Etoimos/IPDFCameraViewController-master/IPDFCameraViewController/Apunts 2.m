//
//  Apunts.m
//  ÉtoimosApp
//
//  Created by Ariadna Tohà on 28/6/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Apunts.h"
#import "AppDelegate.h"
#import <CoreData/CoreData.h>
#import "Temes.h"


@interface Apunts ()

@end

@implementation Apunts
@synthesize taulaApunts,arrayAssignatures,telInfo,infoInteres,nomAssignatura, n;
@synthesize managedObjectContext221=_managedObjectContext221;
@synthesize managedObjectModel221=_managedObjectModel221;
@synthesize persistentStoreCoordinator221=_persistentStoreCoordinator221;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AppDelegate*appDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    _managedObjectContext221=[appDelegate managedObjectContext];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"obrimPantalla");
    self.arrayAssignatures=[[NSMutableArray alloc] init];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    //[defaults3vc setObject:nil forKey:@"Assignatures"];
    //[defaults3vc synchronize];
    if ([defaults3vc objectForKey:@"Assignatures"] ==nil) {
        NSArray*assignatura1=[[NSArray alloc]initWithObjects:@"Filosofia", @"Presentació inicial", nil];
        NSArray*assignatura2=[[NSArray alloc]initWithObjects:@"Català", @"Presentació inicial", nil];
        NSArray*assignatura3=[[NSArray alloc]initWithObjects:@"Castellà", @"Presentació inicial", nil];
        [self.arrayAssignatures addObject:assignatura1];
        [self.arrayAssignatures addObject:assignatura2];
        [self.arrayAssignatures addObject:assignatura3];
        [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
        [defaults3vc synchronize];
        [self.taulaApunts reloadData];
        NSLog(@"Creem l'array");
    }else{
        self.arrayAssignatures = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Assignatures"]];
        NSLog(@"Recuperem l'array");
    }
    [self probaCore];
}

-(void)probaCore{
    NSFetchRequest*request2=[[NSFetchRequest alloc]init];
    NSEntityDescription*lloc2=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext221];
    [request2 setEntity:lloc2];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayAssignatures.count;
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString*CellIdentifier=@"Cell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    NSArray*assig=[self.arrayAssignatures objectAtIndex:indexPath.row];
    cell.textLabel.text=[assig objectAtIndex:0];
    return cell;
}

-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    //[self visualitzarApunt];
    if (indexPath.row == 0) {
        //NSLog(@"Cel.la 0");
        //[self.arrayAssignatures addObject:@"Hola"];
        //NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
        //[defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
        //[defaults3vc synchronize];
        //[self.taulaApunts reloadData];
    }else{
        NSLog(@"Cel.la No es 0");
        /*
        [self.arrayAssignatures removeObjectAtIndex:indexPath.row];
        NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
        [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
        [defaults3vc synchronize];
        [self.taulaApunts reloadData];
        */
    }
    UITableViewCell*cell=[self.taulaApunts cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    n=(int)indexPath.row;
    [self anarTema];
    
}

-(void) anarTema{
    [self performSegueWithIdentifier:@"anarTemes" sender:self];
}

-(NSString*)tableView:(UITableView*)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0 && self.arrayAssignatures.count>0){
        return NSLocalizedString(@"Eliminar",);
    }else{
        return nil;
    }
}

-(UITableViewCellEditingStyle)tableView:(UITableView*)tableView editingStyleForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (self.arrayAssignatures.count>0 && indexPath.section==0){
        return UITableViewCellEditingStyleDelete;
    }else{
        return UITableViewCellEditingStyleNone;
    }
}

-(void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0 && self.arrayAssignatures.count>0){
        if (editingStyle==UITableViewCellEditingStyleDelete){
            //self.indexpath2=indexPath;
            //[self alertaBorrar];
            NSLog(@"Eliminant");
            [self borrarTot];
            /*[self.arrayAssignatures removeObjectAtIndex:indexPath.row];
            NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
            [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
            [defaults3vc synchronize];
            [self.taulaApunts reloadData];*/
        }else{
            if (editingStyle==UITableViewCellEditingStyleNone){
                
            }
        }
    }
}

-(void)borrarTot{
    UIAlertView *eliminarAssign = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Eliminar assignatura",) message:NSLocalizedString(@"Si elimines l'assignatura es borraran tots els temes que conté i també els apunts",) delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel·lar",) otherButtonTitles:NSLocalizedString(@"Eliminar",),nil];
        [eliminarAssign show];
    /*NSArray*assig=[self.arrayAssignatures objectAtIndex:index.row];
    NSString*recuperem=[assig objectAtIndex:0];
    [self.arrayAssignatures removeObjectAtIndex:index.row];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
    [defaults3vc synchronize];
    [self.taulaApunts reloadData];
    
    NSFetchRequest*request12=[[NSFetchRequest alloc]init];
    NSEntityDescription*amics12=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext221];
    [request12 setEntity:amics12];
    NSPredicate*predicate12=[[NSPredicate alloc]init];
    
    predicate12=[NSPredicate predicateWithFormat:@"(assignatura == %@)", recuperem];
   
    [request12 setPredicate:predicate12];
    NSError*error22;
    NSArray*matchingData12=[self.managedObjectContext221 executeFetchRequest:request12 error:&error22];
    NSLog(@"%@%lu", @"Hem borrat apunts: ", (unsigned long)matchingData12.count);
    if (matchingData12.count>0){
        for (int i=0;i<matchingData12.count;i++){
            NSManagedObject*missatgeBorrar=[matchingData12 objectAtIndex:i];
            [self.managedObjectContext221 deleteObject:missatgeBorrar];
            NSError*error33;
            if (![self.managedObjectContext221 save:&error33]){
        
                
            }
        }
    }
*/
}

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==1){
        NSLog(@"Clicat CONTINUAR");
//        [self eliminarAssignatura];
    }
}

/*-(void)eliminarAssignatura:(NSIndexPath*)index{
    NSLog(@"assignatura ELIMINADA");
    NSArray*assig=[self.arrayAssignatures objectAtIndex:index.row];
    NSString*recuperem=[assig objectAtIndex:0];
    [self.arrayAssignatures removeObjectAtIndex:index.row];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
    [defaults3vc synchronize];
    [self.taulaApunts reloadData];
    
    /*NSFetchRequest*request12=[[NSFetchRequest alloc]init];
    NSEntityDescription*amics12=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext221];
    [request12 setEntity:amics12];
    NSPredicate*predicate12=[[NSPredicate alloc]init];
    
    predicate12=[NSPredicate predicateWithFormat:@"(assignatura == %@)", recuperem];
    
    [request12 setPredicate:predicate12];
    NSError*error22;
    NSArray*matchingData12=[self.managedObjectContext221 executeFetchRequest:request12 error:&error22];
    NSLog(@"%@%lu", @"Hem borrat apunts: ", (unsigned long)matchingData12.count);
    if (matchingData12.count>0){
        for (int i=0;i<matchingData12.count;i++){
            NSManagedObject*missatgeBorrar=[matchingData12 objectAtIndex:i];
            [self.managedObjectContext221 deleteObject:missatgeBorrar];
            NSError*error33;
            if (![self.managedObjectContext221 save:&error33]){
                
                
            }
        }
    }
}*/
- (IBAction)crearAssignatura:(id)sender {
    
    self.nomAssignatura=@"";
    self.telInfo=[[UITextField alloc]initWithFrame:CGRectMake(10,10,280,44)];
    self.telInfo.text=@"";
    //self.nouValor=@" ";
    self.telInfo.keyboardType=UIKeyboardTypeNumberPad;
    //self.nouValor=@"nom";
    self.telInfo.placeholder=NSLocalizedString(@"Assignatura",);
    self.telInfo.keyboardType=UIKeyboardTypeDefault;
    self.telInfo.delegate=self;
    self.telInfo.backgroundColor=[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1];
    self.telInfo.layer.cornerRadius=8;
    self.telInfo.layer.masksToBounds=YES;
    self.telInfo.textAlignment=NSTextAlignmentCenter;
    //self.telInfo.textColor=[UIColor colorWithRed:rojoLletra/255.0 green:verdeLletra/255.0 blue:azulLletra/255.0 alpha:1];
    //self.telInfo.font=[UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:20];
    CGFloat tamanyPantalla=[[UIScreen mainScreen] bounds].size.height;
    CGFloat tamanyPantalla2=[[UIScreen mainScreen] bounds].size.width;
    NSLog(@"%f",tamanyPantalla);
    NSLog(@"%f",tamanyPantalla2);
    self.infoInteres=[[UIView alloc]initWithFrame:CGRectMake((tamanyPantalla2-300)/2,tamanyPantalla-450,300,120)];
    self.infoInteres.backgroundColor=[UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1];
    self.infoInteres.layer.cornerRadius=15;
    self.infoInteres.layer.masksToBounds=YES;
    UIButton*accioCancelar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioCancelar setTitle:NSLocalizedString(@"Cancelar",) forState:UIControlStateNormal];
    [accioCancelar addTarget:self action:@selector(cancelar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioCancelar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioCancelar setFrame:CGRectMake(10,70,120,24)];
    UIButton*accioGuardar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioGuardar setTitle:NSLocalizedString(@"Guardar",) forState:UIControlStateNormal];
    [accioGuardar addTarget:self action:@selector(guardar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioGuardar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioGuardar setFrame:CGRectMake(170,70,120,24)];
    [self.infoInteres addSubview:accioGuardar];
    [self.infoInteres addSubview:accioCancelar];
    [self.infoInteres addSubview:self.telInfo];
    [[self view] addSubview:self.infoInteres];
}

-(void)guardar:(NSString*)valorGuardar{
    if ([self.telInfo.text length]>0){
        self.nomAssignatura=self.telInfo.text;
        [self.infoInteres removeFromSuperview];
        NSLog(@"%@%@",@"Valor nomAssignatura: ",self.nomAssignatura);
        [self contactarServidor];
        //[self carpetaNova];
    }
}
-(void)carpetaNova{
    NSArray*novaAssignatura=[[NSArray alloc]initWithObjects:self.nomAssignatura, @"Presentació inicial", nil];
    [self.arrayAssignatures addObject:novaAssignatura];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
    [defaults3vc synchronize];
    [self.taulaApunts reloadData];
    NSLog(@"Carpeta creada");
}

-(void)cancelar:(NSString*)valorGuardar{
    self.nomAssignatura=@"";
    [self.infoInteres removeFromSuperview];
}

-(BOOL)textFieldShouldReturn:(UITextField*)textField{
    [self.telInfo resignFirstResponder];
    return YES;
}

-(void)visualitzarApunt{
    NSFetchRequest*request=[[NSFetchRequest alloc]init];
    NSEntityDescription*chat=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext221];
    [request setEntity:chat];
    NSSortDescriptor*sortDescriptor=[NSSortDescriptor sortDescriptorWithKey:@"dataCreacio" ascending:NO];
    NSArray*sortDescriptors=[[NSArray alloc]initWithObjects:sortDescriptor, nil];
    [request setSortDescriptors:sortDescriptors];
    
    //NSPredicate*predicate12=[[NSPredicate alloc]init];
    
    //predicate12=[NSPredicate predicateWithFormat:@"(tel == %@) && (esSecret == %@)",telefon,SIR];
   
    //[request setPredicate:predicate12];
    
    NSError*error;
    NSArray*mutableFetchRequest=[self.managedObjectContext221 executeFetchRequest:request error:&error];
    if (mutableFetchRequest==nil){
        NSLog(@"No hi ha cap apunt");
    }else{
        NSLog(@"%@%lu",@"Tenim apunts: ",(unsigned long)mutableFetchRequest.count);
    }
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"anarTemes"]){
        [[segue destinationViewController] setA:n];
    }
}

-(void)contactarServidor{
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    NSString*assignatura=self.nomAssignatura;
    NSString*usuari=[defaults3vc objectForKey:@"usuari"];
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  assignatura,@"assignatura",
                                  usuari,@"usuari",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/assignatura.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if ([newStr isEqualToString:@"ok"]){
            dispatch_async (dispatch_get_main_queue (),^{
                [self carpetaNova];
            });
        }
    }];
}

@end
