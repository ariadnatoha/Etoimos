//
//  Selectivitat.m
//  Étoimos
//
//  Created by Ariadna Tohà on 5/10/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Selectivitat.h"

@interface Selectivitat ()


@end

@implementation Selectivitat
@synthesize taulaEnlla, arrayEnlla, arrayUrl;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString*primerEnlla=@"selecat.cat";
    NSString*segonEnlla=@"universitats.gencat.cat";
    NSString*tercerEnlla=@"Posa't a prova";
    //NSString*quartEnlla=@"4";
    NSString*cinqueEnlla=@"cambridgeenglish.org";
    self.arrayEnlla=[[NSArray alloc] initWithObjects: primerEnlla, segonEnlla, tercerEnlla, cinqueEnlla, nil];
    
    NSString*primerUrl=@"https://selecat.cat";
    NSString*segonUrl=@"http://universitats.gencat.cat/ca/pau/model_examens/";
    NSString*tercerUrl=@"http://aplicacions.universitats.gencat.cat/posat/AppJava/frontoffice/?1";
    //NSString*quartUrl=@"9";
    NSString*cinqueUrl=@"http://www.cambridgeenglish.org";
    self.arrayUrl=[[NSArray alloc] initWithObjects: primerUrl, segonUrl, tercerUrl, cinqueUrl, nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayEnlla.count;
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString*CellIdentifier=@"Cell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell){
        /*/
         if (indexPath.row == 0){
         cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
         cell.detailTextLabel.text=@"hola";
         }else{
         */
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        //}
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    cell.textLabel.text=[self.arrayEnlla objectAtIndex:indexPath.row];
    return cell;
}

-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[self.arrayUrl objectAtIndex:indexPath.row]]];
}

- (IBAction)enrere:(id)sender {
        [self dismissViewControllerAnimated:YES completion:nil];
}

@end
