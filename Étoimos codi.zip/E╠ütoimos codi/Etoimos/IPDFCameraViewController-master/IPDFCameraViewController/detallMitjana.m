//
//  detallMitjana.m
//  Étoimos
//
//  Created by Miquel Perera on 30/10/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "detallMitjana.h"

@interface detallMitjana ()

@end

@implementation detallMitjana
@synthesize naviBar,titol,assigMitg,valors,valor1,valor2,valor3,pond1,pond2,pond3,texteNota1,texteNota2,texteNota3,texteProm1,texteProm2,texteProm3,infoInteres,telInfo,donVinc,texteActitud,texteActitudProm,texteExamensNota1,texteExamensProm1,texteExamensProm2,texteExercicisNota1,texteExercicisNota2,texteExercicisProm1,texteExercicisProm2,tezteExamensNota2,actitud1,pondActitud1,notaAltresExamens1,pondAltresExamens1,notaAltresExamens2,pondAltresExamens2,notaExercicis1,pondExercicis1,notaExercicis2,pondExercicis2,valorMitjana;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.donVinc=0;
    self.valor1=0;
    self.valor2=0;
    self.valor3=0;
    self.pond1=0;
    self.pond2=0;
    self.pond3=0;
    self.actitud1=0;
    self.pondActitud1=0;
    self.notaAltresExamens1=0;
    self.pondAltresExamens1=0;
    self.notaAltresExamens2=0;
    self.pondAltresExamens2=0;
    self.notaExercicis1=0;
    self.pondExercicis1=0;
    self.notaExercicis2=0;
    self.pondExercicis2=0;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.titol.title=self.assigMitg;
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    if ([defaults3vc objectForKey:@"Mitjanes"] !=nil) {
        NSMutableArray*arrayGuardat = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Mitjanes"]];
        for (int k=0; k<arrayGuardat.count; k++) {
            NSDictionary*valorMitjanes=[arrayGuardat objectAtIndex:k];
            if ([[valorMitjanes objectForKey:@"nomMitjana"] isEqualToString:self.assigMitg]) {
                self.valor1 = [[valorMitjanes objectForKey:@"valor1"] floatValue];
                self.pond1 = [[valorMitjanes objectForKey:@"pond1"] floatValue];
                self.valor2 = [[valorMitjanes objectForKey:@"valor2"] floatValue];
                self.pond2 = [[valorMitjanes objectForKey:@"pond2"] floatValue];
                self.valor3 = [[valorMitjanes objectForKey:@"valor3"] floatValue];
                self.pond3 = [[valorMitjanes objectForKey:@"pond3"] floatValue];
                self.actitud1=[[valorMitjanes objectForKey:@"actitud1"] floatValue];
                self.pondActitud1=[[valorMitjanes objectForKey:@"pondActitud1"] floatValue];
                self.notaAltresExamens1=[[valorMitjanes objectForKey:@"notaAltresExamens1"] floatValue];
                self.pondAltresExamens1=[[valorMitjanes objectForKey:@"pondAltresExamens1"] floatValue];
                self.notaAltresExamens2=[[valorMitjanes objectForKey:@"notaAltresExamens2"] floatValue];
                self.pondAltresExamens2=[[valorMitjanes objectForKey:@"pondAltresExamens2"] floatValue];
                self.notaExercicis1=[[valorMitjanes objectForKey:@"notaExercicis11"] floatValue];
                self.pondExercicis1=[[valorMitjanes objectForKey:@"pondExercicis1"] floatValue];
                self.notaExercicis2=[[valorMitjanes objectForKey:@"notaExercicis2"] floatValue];
                self.pondExercicis2=[[valorMitjanes objectForKey:@"pondExercicis2"] floatValue];
            }
        }
    }
    [self canviarBotons];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)crearVista:(NSString*)don {
    [self.infoInteres removeFromSuperview];
    self.telInfo=[[UITextField alloc]initWithFrame:CGRectMake(10,10,280,44)];
    self.telInfo.text=@"";
    self.telInfo.placeholder=don;
    self.telInfo.keyboardType=UIKeyboardTypeDecimalPad;
    //self.telInfo.keyboardType=UIKeyboardTypeNumbersAndPunctuation;
    self.telInfo.delegate=self;
    self.telInfo.backgroundColor=[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1];
    self.telInfo.layer.cornerRadius=8;
    self.telInfo.layer.masksToBounds=YES;
    self.telInfo.textAlignment=NSTextAlignmentCenter;
    CGFloat tamanyPantalla=[[UIScreen mainScreen] bounds].size.height;
    CGFloat tamanyPantalla2=[[UIScreen mainScreen] bounds].size.width;
    NSLog(@"%f",tamanyPantalla);
    NSLog(@"%f",tamanyPantalla2);
    self.infoInteres=[[UIView alloc]initWithFrame:CGRectMake((tamanyPantalla2-300)/2,tamanyPantalla-450,300,120)];
    self.infoInteres.backgroundColor=[UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1];
    self.infoInteres.layer.cornerRadius=15;
    self.infoInteres.layer.masksToBounds=YES;
    UIButton*accioCancelar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioCancelar setTitle:NSLocalizedString(@"Cancel·lar",) forState:UIControlStateNormal];
    [accioCancelar addTarget:self action:@selector(cancelar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioCancelar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioCancelar setFrame:CGRectMake(10,70,120,24)];
    UIButton*accioGuardar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioGuardar setTitle:NSLocalizedString(@"Guardar",) forState:UIControlStateNormal];
    [accioGuardar addTarget:self action:@selector(guardar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioGuardar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioGuardar setFrame:CGRectMake(170,70,120,24)];
    [self.infoInteres addSubview:accioGuardar];
    [self.infoInteres addSubview:accioCancelar];
    [self.infoInteres addSubview:self.telInfo];
    [[self view] addSubview:self.infoInteres];
}

-(void)cancelar:(NSString*)valorGuardar{
    [self.infoInteres removeFromSuperview];
}

-(void)guardar:(NSString*)valorGuardar{
    if([self.telInfo.text length]>0){
        [self.infoInteres removeFromSuperview];
        //NSLog(@"%d",self.donVinc);
        //NSLog(@"%@",self.telInfo.text);
        NSString*valorAjustat=[self.telInfo.text stringByReplacingOccurrencesOfString:@"," withString:@"."];
        if (self.donVinc==1) {
            self.valor1=[valorAjustat floatValue];
        }
        if (self.donVinc==2) {
            self.valor2=[valorAjustat floatValue];
        }
        if (self.donVinc==3) {
            self.valor3=[valorAjustat floatValue];
        }
        if (self.donVinc==4) {
            self.pond1=[valorAjustat floatValue];
        }
        if (self.donVinc==5) {
            self.pond2=[valorAjustat floatValue];
        }
        if (self.donVinc==6) {
            self.pond3=[valorAjustat floatValue];
        }
        if (self.donVinc==7) {
            self.actitud1=[valorAjustat floatValue];
        }
        if (self.donVinc==8) {
            self.pondActitud1=[valorAjustat floatValue];
        }
        if (self.donVinc==9) {
            self.notaAltresExamens1=[valorAjustat floatValue];
        }
        if (self.donVinc==10) {
            self.notaAltresExamens2=[valorAjustat floatValue];
        }
        if (self.donVinc==11) {
            self.pondAltresExamens1=[valorAjustat floatValue];
        }
        if (self.donVinc==12) {
            self.pondAltresExamens2=[valorAjustat floatValue];
        }
        if (self.donVinc==13) {
            self.notaExercicis1=[valorAjustat floatValue];
        }
        if (self.donVinc==14) {
            self.notaExercicis2=[valorAjustat floatValue];
        }
        if (self.donVinc==15) {
            self.pondExercicis1=[valorAjustat floatValue];
        }
        if (self.donVinc==16) {
            self.pondExercicis2=[valorAjustat floatValue];
        }
        self.donVinc=0;
        [self canviarBotons];
        NSDictionary*valorMitjanes2=[NSDictionary dictionaryWithObjectsAndKeys:
            self.assigMitg,@"nomMitjana",
            [NSString stringWithFormat:@"%.2f",self.valor1] ,@"valor1",
            [NSString stringWithFormat:@"%.2f",self.pond1],@"pond1",
            [NSString stringWithFormat:@"%.2f",self.valor2],@"valor2",
            [NSString stringWithFormat:@"%.2f",self.pond2],@"pond2",
            [NSString stringWithFormat:@"%.2f",self.valor3],@"valor3",
            [NSString stringWithFormat:@"%.2f",self.pond3],@"pond3",
            [NSString stringWithFormat:@"%.2f",self.actitud1],@"actitud1",
            [NSString stringWithFormat:@"%.2f",self.pondActitud1],@"pondActitud1",
            [NSString stringWithFormat:@"%.2f",self.notaAltresExamens1],@"notaAltresExamens1",
            [NSString stringWithFormat:@"%.2f",self.pondAltresExamens1],@"pondAltresExamens1",
            [NSString stringWithFormat:@"%.2f",self.notaAltresExamens2],@"notaAltresExamens2",
            [NSString stringWithFormat:@"%.2f",self.pondAltresExamens2],@"pondAltresExamens2",
            [NSString stringWithFormat:@"%.2f",self.notaExercicis1],@"notaExercicis1",
            [NSString stringWithFormat:@"%.2f",self.pondExercicis1],@"pondExercicis1",
            [NSString stringWithFormat:@"%.2f",self.notaExercicis2],@"notaExercicis2",
            [NSString stringWithFormat:@"%.2f",self.pondExercicis2],@"pondExercicis2",
            nil
        ];
        NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
        if ([defaults3vc objectForKey:@"Mitjanes"] !=nil) {
            NSMutableArray*arrayGuardat = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Mitjanes"]];
            BOOL trobat = NO;
            for (int k=0; k<arrayGuardat.count; k++) {
                NSDictionary*valorMitjanes=[arrayGuardat objectAtIndex:k];
                if ([[valorMitjanes objectForKey:@"nomMitjana"] isEqualToString:self.assigMitg]) {
                    trobat = YES;
                    [arrayGuardat removeObjectAtIndex:k];
                    [arrayGuardat addObject:valorMitjanes2];
                    [defaults3vc setObject:arrayGuardat forKey:@"Mitjanes"];
                    [defaults3vc synchronize];
                }
            }
            if (!trobat) {
                [arrayGuardat addObject:valorMitjanes2];
                [defaults3vc setObject:arrayGuardat forKey:@"Mitjanes"];
                [defaults3vc synchronize];
            }
        }else{
            NSArray*novaArray=[[NSArray alloc] initWithObjects:valorMitjanes2, nil];
            [defaults3vc setObject:novaArray forKey:@"Mitjanes"];
            [defaults3vc synchronize];
        }
    }
}

-(void)canviarBotons{
    NSString*nota=@"Nota";
    NSString*percen=@"%";
    self.texteNota1.tintColor=[UIColor blueColor];
    self.texteNota2.tintColor=[UIColor blueColor];
    self.texteNota3.tintColor=[UIColor blueColor];
    self.texteProm1.tintColor=[UIColor blueColor];
    self.texteProm2.tintColor=[UIColor blueColor];
    self.texteProm3.tintColor=[UIColor blueColor];
    self.texteActitud.tintColor=[UIColor blueColor];
    self.texteActitudProm.tintColor=[UIColor blueColor];
    self.texteExamensNota1.tintColor=[UIColor blueColor];
    self.tezteExamensNota2.tintColor=[UIColor blueColor];
    self.texteExamensProm1.tintColor=[UIColor blueColor];
    self.texteExamensProm2.tintColor=[UIColor blueColor];
    self.texteExercicisNota1.tintColor=[UIColor blueColor];
    self.texteExercicisNota2.tintColor=[UIColor blueColor];
    self.texteExercicisProm1.tintColor=[UIColor blueColor];
    self.texteExercicisProm2.tintColor=[UIColor blueColor];
    if (self.valor1 !=0) {
        [self.texteNota1 setTitle:[NSString stringWithFormat:@"%.2f",self.valor1] forState:UIControlStateNormal];
        //self.texteNota1.tintColor=[UIColor blueColor];
    }else{
        [self.texteNota1 setTitle:nota forState:UIControlStateNormal];
        if (self.pond1 !=0) {
            self.texteNota1.tintColor=[UIColor redColor];
        }
    }
    
    if (self.valor2 !=0) {
        [self.texteNota2 setTitle:[NSString stringWithFormat:@"%.2f",self.valor2] forState:UIControlStateNormal];
        //self.texteNota2.tintColor=[UIColor blueColor];
    }else{
        [self.texteNota2 setTitle:nota forState:UIControlStateNormal];
        if (self.pond2 !=0) {
            self.texteNota2.tintColor=[UIColor redColor];
        }
    }
    
    if (self.valor3 !=0) {
        [self.texteNota3 setTitle:[NSString stringWithFormat:@"%.2f",self.valor3] forState:UIControlStateNormal];
        //self.texteNota3.tintColor=[UIColor blueColor];
    }else{
        [self.texteNota3 setTitle:nota forState:UIControlStateNormal];
        if (self.pond3 !=0) {
            self.texteNota3.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pond1 !=0) {
        [self.texteProm1 setTitle:[NSString stringWithFormat:@"%.0f%@",self.pond1,@" %"] forState:UIControlStateNormal];
        //self.texteProm1.tintColor=[UIColor blueColor];
    }else{
        [self.texteProm1 setTitle:percen forState:UIControlStateNormal];
        if (self.valor1 !=0) {
            self.texteProm1.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pond2 !=0) {
        [self.texteProm2 setTitle:[NSString stringWithFormat:@"%.0f%@",self.pond2,@" %"] forState:UIControlStateNormal];
        //self.texteProm2.tintColor=[UIColor blueColor];
    }else{
        [self.texteProm2 setTitle:percen forState:UIControlStateNormal];
        if (self.valor2 !=0) {
            self.texteProm2.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pond3 !=0) {
        [self.texteProm3 setTitle:[NSString stringWithFormat:@"%.0f%@",self.pond3,@" %"] forState:UIControlStateNormal];
        //self.texteProm3.tintColor=[UIColor blueColor];
    }else{
        [self.texteProm3 setTitle:percen forState:UIControlStateNormal];
        if (self.valor3 !=0) {
            self.texteProm3.tintColor=[UIColor redColor];
        }
    }
    
    if (self.actitud1 !=0) {
        [self.texteActitud setTitle:[NSString stringWithFormat:@"%.2f",self.actitud1] forState:UIControlStateNormal];
        //self.texteActitud.tintColor=[UIColor blueColor];
    }else{
        [self.texteActitud setTitle:nota forState:UIControlStateNormal];
        if (self.pondActitud1 !=0) {
            self.texteActitud.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pondActitud1 !=0) {
        [self.texteActitudProm setTitle:[NSString stringWithFormat:@"%.0f%@",self.pondActitud1,@" %"] forState:UIControlStateNormal];
        //self.texteActitudProm.tintColor=[UIColor blueColor];
    }else{
        [self.texteActitudProm setTitle:percen forState:UIControlStateNormal];
        if (self.actitud1 !=0) {
            self.texteActitudProm.tintColor=[UIColor redColor];
        }
    }
    
    if (self.notaAltresExamens1 !=0) {
        [self.texteExamensNota1 setTitle:[NSString stringWithFormat:@"%.2f",self.notaAltresExamens1] forState:UIControlStateNormal];
        //self.texteExamensNota1.tintColor=[UIColor blueColor];
    }else{
        [self.texteExamensNota1 setTitle:nota forState:UIControlStateNormal];
        if (self.pondAltresExamens1 !=0) {
            self.texteExamensNota1.tintColor=[UIColor redColor];
        }
    }
    
    if (self.notaAltresExamens2 !=0) {
        [self.tezteExamensNota2 setTitle:[NSString stringWithFormat:@"%.2f",self.notaAltresExamens2] forState:UIControlStateNormal];
        //self.tezteExamensNota2.tintColor=[UIColor blueColor];
    }else{
        [self.tezteExamensNota2 setTitle:nota forState:UIControlStateNormal];
        if (self.pondAltresExamens2 !=0) {
            self.tezteExamensNota2.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pondAltresExamens1 !=0) {
        [self.texteExamensProm1 setTitle:[NSString stringWithFormat:@"%.0f%@",self.pondAltresExamens1,@" %"] forState:UIControlStateNormal];
        //self.texteExamensProm1.tintColor=[UIColor blueColor];
    }else{
        [self.texteExamensProm1 setTitle:percen forState:UIControlStateNormal];
        if (self.notaAltresExamens1 !=0) {
            self.texteExamensProm1.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pondAltresExamens2 !=0) {
        [self.texteExamensProm2 setTitle:[NSString stringWithFormat:@"%.0f%@",self.pondAltresExamens2,@" %"] forState:UIControlStateNormal];
        //self.texteExamensProm2.tintColor=[UIColor blueColor];
    }else{
        [self.texteExamensProm2 setTitle:percen forState:UIControlStateNormal];
        if (self.notaAltresExamens2 !=0) {
            self.texteExamensProm2.tintColor=[UIColor redColor];
        }
    }
    
    if (self.notaExercicis1 !=0) {
        [self.texteExercicisNota1 setTitle:[NSString stringWithFormat:@"%.2f",self.notaExercicis1] forState:UIControlStateNormal];
        //self.texteExercicisNota1.tintColor=[UIColor blueColor];
    }else{
        [self.texteExercicisNota1 setTitle:nota forState:UIControlStateNormal];
        if (self.pondExercicis1 !=0) {
            self.texteExercicisNota1.tintColor=[UIColor redColor];
        }
    }
    
    if (self.notaExercicis2 !=0) {
        [self.texteExercicisNota2 setTitle:[NSString stringWithFormat:@"%.2f",self.notaExercicis2] forState:UIControlStateNormal];
        //self.texteExercicisNota2.tintColor=[UIColor blueColor];
    }else{
        [self.texteExercicisNota2 setTitle:nota forState:UIControlStateNormal];
        if (self.pondExercicis2 !=0) {
            self.texteExercicisNota2.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pondExercicis1 !=0) {
        [self.texteExercicisProm1 setTitle:[NSString stringWithFormat:@"%.0f%@",self.pondExercicis1,@" %"] forState:UIControlStateNormal];
        //self.texteExercicisProm1.tintColor=[UIColor blueColor];
    }else{
        [self.texteExercicisProm1 setTitle:percen forState:UIControlStateNormal];
        if (self.notaExercicis1 !=0) {
            self.texteExercicisProm1.tintColor=[UIColor redColor];
        }
    }
    
    if (self.pondExercicis2 !=0) {
        [self.texteExercicisProm2 setTitle:[NSString stringWithFormat:@"%.0f%@",self.pondExercicis2,@" %"] forState:UIControlStateNormal];
        //self.texteExercicisProm2.tintColor=[UIColor blueColor];
    }else{
        [self.texteExercicisProm2 setTitle:percen forState:UIControlStateNormal];
        if (self.notaExercicis2 !=0) {
            self.texteExercicisProm2.tintColor=[UIColor redColor];
        }
    }
    [self mostrarMitjana];
}

-(void)mostrarMitjana{
    int comptadorValors=0;
    int control1= 0;
    int control2= 0;
    int control3= 0;
    int control4= 0;
    int control5= 0;
    int control6= 0;
    int control7= 0;
    int control8= 0;
    if (self.valor1*self.pond1 !=0) {
        comptadorValors=comptadorValors+1;
        control1=1;
    }
    if (self.valor2*self.pond2 !=0) {
        comptadorValors=comptadorValors+1;
        control2=1;
    }
    if (self.valor3*self.pond3 !=0) {
        comptadorValors=comptadorValors+1;
        control3=1;
        
    }
    if (self.actitud1*self.pondActitud1 !=0) {
        comptadorValors=comptadorValors+1;
        control4=1;
        
    }
    if (self.notaAltresExamens1*self.pondAltresExamens1 !=0) {
        comptadorValors=comptadorValors+1;
        control5=1;
        
    }
    if (self.notaAltresExamens2*self.pondAltresExamens2 !=0) {
        comptadorValors=comptadorValors+1;
        control6=1;
        
    }
    if (self.notaExercicis1*self.pondExercicis1 !=0) {
        comptadorValors=comptadorValors+1;
        control7=1;
        
    }
    if (self.notaExercicis2*self.pondExercicis2 !=0) {
        comptadorValors=comptadorValors+1;
        control8=1;
    }
    NSLog(@"%@%d",@"Tenim notes: ",comptadorValors);
    if (comptadorValors > 0) {
        float mitjana = ((self.valor1*self.pond1) + (self.valor2*self.pond2) + (self.valor3*self.pond3) + (self.actitud1*self.pondActitud1) + (self.notaAltresExamens1*self.pondAltresExamens1) + (self.notaAltresExamens2*self.pondAltresExamens2) + (self.notaExercicis1*self.pondExercicis1) + (self.notaExercicis2*self.pondExercicis2)) / (self.pond1*control1 + self.pond2*control2 + self.pond3*control3 + self.pondActitud1*control4 + self.pondAltresExamens1*control5 + self.pondAltresExamens2*control6 + self.pondExercicis1*control7 + self.pondExercicis2*control8);
        if (mitjana>0 && mitjana <5) {
            self.valorMitjana.textColor=[UIColor redColor];
        }else{
            if (mitjana >= 5 && mitjana < 7) {
                self.valorMitjana.textColor=[UIColor orangeColor];
            }else{
                if (mitjana >=7) {
                    self.valorMitjana.textColor=[UIColor greenColor];
                }
            }
        }
        self.valorMitjana.text=[NSString stringWithFormat:@"%@%.2f",@"La mitjana és ",mitjana];
    }else{
        self.valorMitjana.textColor=[UIColor blackColor];
        self.valorMitjana.text=@"Nota mitjana";
    }
}

-(BOOL)textFieldShouldReturn:(UITextField*)textField{
    [self.telInfo resignFirstResponder];
    return YES;
}

- (IBAction)nota1:(id)sender {
    self.donVinc=1;
    [self crearVista:@"nota"];
}

- (IBAction)nota2:(id)sender {
    self.donVinc=2;
    [self crearVista:@"nota"];
}

- (IBAction)nota3:(id)sender {
    self.donVinc=3;
    [self crearVista:@"nota"];
}

- (IBAction)promig1:(id)sender {
    self.donVinc=4;
    [self crearVista:@"%"];
}

- (IBAction)promig2:(id)sender {
    self.donVinc=5;
    [self crearVista:@"%"];
}

- (IBAction)promig3:(id)sender {
    self.donVinc=6;
    [self crearVista:@"%"];
}

- (IBAction)notaActitud:(id)sender {
    self.donVinc=7;
    [self crearVista:@"nota"];
}

- (IBAction)promActitud:(id)sender {
    self.donVinc=8;
    [self crearVista:@"%"];
}

- (IBAction)notaAltresExamens1:(id)sender {
    self.donVinc=9;
    [self crearVista:@"nota"];
}

- (IBAction)notaAltresExamens2:(id)sender {
    self.donVinc=10;
    [self crearVista:@"nota"];
}

- (IBAction)promAltresExamens1:(id)sender {
    self.donVinc=11;
    [self crearVista:@"%"];
}

- (IBAction)promAltresExamens2:(id)sender {
    self.donVinc=12;
    [self crearVista:@"%"];
}

- (IBAction)noraExercicis1:(id)sender {
    self.donVinc=13;
    [self crearVista:@"nota"];
}

- (IBAction)notaExercicis2:(id)sender {
    self.donVinc=14;
    [self crearVista:@"nota"];
}

- (IBAction)promExercicis1:(id)sender {
    self.donVinc=15;
    [self crearVista:@"%"];
}

- (IBAction)promExercicis2:(id)sender {
    self.donVinc=16;
    [self crearVista:@"%"];
}

- (IBAction)accioTornar:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
