//
//  registre.m
//  IPDFCameraViewControllerDemo
//
//  Created by Miquel Perera on 16/6/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "registre.h"

@interface registre ()

@end

@implementation registre
@synthesize etiquetaNom,etiquetaCorreu,etiquetaClau,comprovacioClau,nomUsuari;

- (void)viewDidLoad {
    [super viewDidLoad];
    etiquetaClau.delegate=self;
    etiquetaCorreu.delegate=self;
    etiquetaNom.delegate=self;
    comprovacioClau.delegate=self;
    self.nomUsuari=@"";
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSLog(@"%@%@",@"Return: ",textField);
    [etiquetaNom resignFirstResponder];
    [etiquetaCorreu resignFirstResponder];
    [etiquetaClau resignFirstResponder];
    [comprovacioClau resignFirstResponder];
    if (textField == comprovacioClau) {
        [self comprovacioUsuari];
    }
    return YES;
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    NSLog(@"%@%@",@"End Editing: ",textField);
    [etiquetaNom resignFirstResponder];
    [etiquetaCorreu resignFirstResponder];
    [etiquetaClau resignFirstResponder];
    [comprovacioClau resignFirstResponder];
    return YES;
}

-(void)comprovacioUsuari{
    BOOL contrassenya = NO;
    BOOL tenimUsuari = NO;
    BOOL tenimMail = NO;
    if ([etiquetaClau.text length] > 5) {
        NSLog(@"%@%lu",@"Longitud correcta, es: ",[etiquetaClau.text length]);
        if ([etiquetaClau.text isEqualToString:comprovacioClau.text]){
            NSLog(@"Log coincideixen");
            contrassenya= YES;
        }else{
            NSLog(@"Log No coincideixen");
            UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"No coincideixen",) message:NSLocalizedString(@"Torna a entrar contrasenyes",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
            [imatgeGuardada show];
        }
    }else{
        NSLog(@"%@%lu",@"Longitud no es correcta, es: ",[etiquetaClau.text length]);
        UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Massa curta",) message:NSLocalizedString(@"Torna a entrar contrasenyes",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
        [imatgeGuardada show];
    }
    if ([etiquetaNom.text length] > 0) {
        tenimUsuari = YES;
    }
    if ([etiquetaCorreu.text length] > 0) {
        tenimMail = YES;
    }
    if (contrassenya && tenimMail && tenimUsuari) {
        [self comunicarServidor];
    }
}

-(void)comunicarServidor{
    NSLog(@"Anem a contactar amb Servidor");
    self.nomUsuari=etiquetaNom.text;
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  etiquetaNom.text,@"usuari",
                                  etiquetaClau.text,@"contrassenya",
                                  etiquetaCorreu.text,@"mail",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/alta.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if (data && !error1) {
            if ([newStr isEqualToString:@"35"]) {
                [self altaCorrecta];
            }
            if ([newStr isEqualToString:@"24"]) {
                [self usuariExistent];
                
            }
        }
        
        
    }];
}

/*
-(void) anarPantallaPrincipal{
    [self performSegueWithIdentifier:@"pantallaPrincipal" sender:self];
}
*/

-(void) altaCorrecta{
    dispatch_async (dispatch_get_main_queue (),^{
        NSLog(@"correcta");
        NSUserDefaults*usu=[NSUserDefaults standardUserDefaults];
        [usu setObject:self.nomUsuari forKey:@"usuari"];
        [usu setObject:nil forKey:@"Assignatures"];
        [usu synchronize];
        //[self registrat:self];
        //[self performSegueWithIdentifier:@"pantallaPrincipal" sender:self];
        //[self dismissViewControllerAnimated:YES completion:nil];
        [self performSelector:@selector(altaOk) withObject:nil afterDelay:0.1];
    });
    
}
-(void) usuariExistent{
    dispatch_async (dispatch_get_main_queue (),^{
        self.nomUsuari=@"";
        UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"L'usuari ja existeix",) message:NSLocalizedString(@"Canvia el nom d'usuari",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
        [imatgeGuardada show];
    });
}

- (IBAction)accioOk:(id)sender {
    [etiquetaNom resignFirstResponder];
    [etiquetaCorreu resignFirstResponder];
    [etiquetaClau resignFirstResponder];
    [comprovacioClau resignFirstResponder];
    [self comprovacioUsuari];
    //[self performSegueWithIdentifier:@"comencem" sender:self];
}

- (IBAction)accioEnrere:(id)sender {
    //[self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)registrat:(id)sender {
    
}

-(void)altaOk{
    [self performSegueWithIdentifier:@"fet" sender:self];
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"fet"]){
        [segue destinationViewController];
    }
}


@end

