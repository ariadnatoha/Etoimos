//
//  Selectivitat.h
//  Étoimos
//
//  Created by Ariadna Tohà on 5/10/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Selectivitat : UIViewController<UITableViewDelegate,UITableViewDataSource>

- (IBAction)enrere:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *taulaEnlla;
@property (retain,nonatomic) NSArray *arrayEnlla;
@property (retain,nonatomic) NSArray *arrayUrl;
@end
