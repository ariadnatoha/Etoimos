//
//  detallMitjana.h
//  Étoimos
//
//  Created by Miquel Perera on 30/10/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detallMitjana : UIViewController<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UINavigationBar *naviBar;
@property (weak, nonatomic) IBOutlet UINavigationItem *titol;
@property (nonatomic,retain) NSString*assigMitg;
@property (nonatomic,retain) NSDictionary*valors;
@property float valor1;
@property float valor2;
@property float valor3;
@property float pond1;
@property float pond2;
@property float pond3;
@property float actitud1;
@property float pondActitud1;
@property float notaAltresExamens1;
@property float pondAltresExamens1;
@property float notaAltresExamens2;
@property float pondAltresExamens2;
@property float notaExercicis1;
@property float pondExercicis1;
@property float notaExercicis2;
@property float pondExercicis2;

@property int donVinc;
@property (weak, nonatomic) IBOutlet UIButton *texteNota1;
@property (weak, nonatomic) IBOutlet UIButton *texteNota2;
@property (weak, nonatomic) IBOutlet UIButton *texteNota3;
@property (weak, nonatomic) IBOutlet UIButton *texteProm1;
@property (weak, nonatomic) IBOutlet UIButton *texteProm2;
@property (weak, nonatomic) IBOutlet UIButton *texteProm3;
@property (weak, nonatomic) IBOutlet UIButton *texteActitud;
@property (weak, nonatomic) IBOutlet UIButton *texteActitudProm;
@property (weak, nonatomic) IBOutlet UIButton *texteExamensNota1;
@property (weak, nonatomic) IBOutlet UIButton *tezteExamensNota2;
@property (weak, nonatomic) IBOutlet UIButton *texteExamensProm1;
@property (weak, nonatomic) IBOutlet UIButton *texteExamensProm2;
@property (weak, nonatomic) IBOutlet UIButton *texteExercicisNota1;
@property (weak, nonatomic) IBOutlet UIButton *texteExercicisNota2;
@property (weak, nonatomic) IBOutlet UIButton *texteExercicisProm1;
@property (weak, nonatomic) IBOutlet UIButton *texteExercicisProm2;
@property (retain,nonatomic) UIView*infoInteres;
@property (retain,nonatomic) UITextField*telInfo;
@property (weak, nonatomic) IBOutlet UILabel *valorMitjana;

- (IBAction)nota1:(id)sender;
- (IBAction)nota2:(id)sender;
- (IBAction)nota3:(id)sender;
- (IBAction)promig1:(id)sender;
- (IBAction)promig2:(id)sender;
- (IBAction)promig3:(id)sender;
- (IBAction)notaActitud:(id)sender;
- (IBAction)promActitud:(id)sender;
- (IBAction)notaAltresExamens1:(id)sender;
- (IBAction)notaAltresExamens2:(id)sender;
- (IBAction)promAltresExamens1:(id)sender;
- (IBAction)promAltresExamens2:(id)sender;
- (IBAction)noraExercicis1:(id)sender;
- (IBAction)notaExercicis2:(id)sender;
- (IBAction)promExercicis1:(id)sender;
- (IBAction)promExercicis2:(id)sender;

- (IBAction)accioTornar:(id)sender;

@end
