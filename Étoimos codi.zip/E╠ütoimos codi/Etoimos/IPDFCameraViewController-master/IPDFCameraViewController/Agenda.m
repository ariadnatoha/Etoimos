//
//  Agenda.m
//  ÉtoimosApp
//
//  Created by Miquel Perera on 28/6/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Agenda.h"

@interface Agenda ()

@end

@implementation Agenda

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    if (([defaults3vc objectForKey:@"usuari"]==nil) || ([[defaults3vc objectForKey:@"usuari"] isEqualToString:@""])) {
        NSLog(@"No tenim usuari");
        [self performSelector:@selector(anarPantallaPrincipal) withObject:nil afterDelay:0.1];
    }else{
        NSLog(@"%@%@",@"El Nom d'usuari es: ",[defaults3vc objectForKey:@"usuari"]);
        //Anar a pantalla Principal
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)anarPantallaPrincipal{
    [self performSegueWithIdentifier:@"presentacio" sender:self];
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"presentacio"]){
        [segue destinationViewController];
    }
}

-(IBAction)prepareForUnwind:(UIStoryboardSegue *)segue {
}


@end
