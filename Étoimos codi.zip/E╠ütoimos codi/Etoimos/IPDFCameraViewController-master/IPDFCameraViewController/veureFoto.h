//
//  veureFoto.h
//  Étoimos
//
//  Created by Miquel Perera on 2/9/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface veureFoto : UIViewController<UIScrollViewDelegate>{
    IBOutlet UIScrollView*scrollView;
    UIImageView*imageView;
}

@property (nonatomic,retain) UIScrollView*scrollView;
@property (nonatomic,retain) UIImageView*imageView;
@property (nonatomic,strong) UIImage*imatgeRebuda;

@end
