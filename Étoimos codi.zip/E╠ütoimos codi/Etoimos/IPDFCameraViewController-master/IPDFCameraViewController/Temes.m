//
//  Temes.m
//  ÉtoimosApp
//
//  Created by Miquel Perera on 27/7/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Temes.h"
#import "llistatApunts.h"
#import "AppDelegate.h"
#import <CoreData/CoreData.h>

@interface Temes ()

@end

@implementation Temes
@synthesize a, arrayAssignatures, arrayTemes, taulaTemes,navigationItem,infoInteres,telInfo,nomAssignatura,assignaturaEliminar,temaEliminar,indexSeleccionat,anarTema;
@synthesize managedObjectContext221=_managedObjectContext221;
@synthesize managedObjectModel221=_managedObjectModel221;
@synthesize persistentStoreCoordinator221=_persistentStoreCoordinator221;

- (void)viewDidLoad {
    [super viewDidLoad];
    AppDelegate*appDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    _managedObjectContext221=[appDelegate managedObjectContext];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"%@%d", @"el valor de a és ", a);
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    self.arrayAssignatures = [[NSMutableArray alloc] initWithArray:[defaults3vc objectForKey:@"Assignatures"]];
    NSLog(@"%@%lu",@"valor en la possició 0: ", (unsigned long)[self.arrayAssignatures count]);
    self.arrayTemes = [[NSMutableArray alloc]initWithArray:[self.arrayAssignatures objectAtIndex:a]];
    NSLog(@"%@%@",@"valor en la possició 0: ", [self.arrayTemes objectAtIndex:0]);
    NSLog(@"%@%@",@"valor en la possició 1: ", [self.arrayAssignatures objectAtIndex:1]);
    self.navigationItem.title=[self.arrayTemes objectAtIndex:0];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayTemes.count - 1;
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString*CellIdentifier=@"Cell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    cell.textLabel.text=[self.arrayTemes objectAtIndex:(indexPath.row + 1)];
    return cell;
}

-(NSString*)tableView:(UITableView*)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0 && self.arrayTemes.count>1){
        return NSLocalizedString(@"Eliminar",);
    }else{
        return nil;
    }
}

-(UITableViewCellEditingStyle)tableView:(UITableView*)tableView editingStyleForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (self.arrayTemes.count>1 && indexPath.section==0){
        return UITableViewCellEditingStyleDelete;
    }else{
        return UITableViewCellEditingStyleNone;
    }
}

-(void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0 && self.arrayTemes.count>1){
        if (editingStyle==UITableViewCellEditingStyleDelete){
            //self.indexpath2=indexPath;
            //[self alertaBorrar];
            [self borrarTot:indexPath];
            
        }else{
            if (editingStyle==UITableViewCellEditingStyleNone){
                
            }
        }
    }
}

-(void)borrarTot:(NSIndexPath*)index{
    self.assignaturaEliminar=[self.arrayTemes objectAtIndex:0];
    self.temaEliminar=[self.arrayTemes objectAtIndex:(index.row + 1)];
    self.indexSeleccionat=index;
    [self contactarServidorEliminar];
}

-(void)contactarServidorEliminar{
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    NSString*usuari=[defaults3vc objectForKey:@"usuari"];
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  self.assignaturaEliminar,@"assignatura",
                                  usuari,@"usuari",
                                  self.temaEliminar,@"tema",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/baixaTema.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if ([newStr isEqualToString:@"ok"]){
            dispatch_async (dispatch_get_main_queue (),^{
                [self confirmatBorrar];
            });
        }
    }];
}

-(void)confirmatBorrar{
    NSLog(@"Eliminat");
    [self.arrayTemes removeObjectAtIndex:self.indexSeleccionat.row + 1];
    [self.arrayAssignatures replaceObjectAtIndex:a withObject:self.arrayTemes];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
    [defaults3vc synchronize];
    [self.taulaTemes reloadData];
    NSLog(@"Tema esborrat");
    
    NSFetchRequest*request12=[[NSFetchRequest alloc]init];
    NSEntityDescription*amics12=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext221];
    [request12 setEntity:amics12];
    NSPredicate*predicate12=[[NSPredicate alloc]init];
    
    predicate12=[NSPredicate predicateWithFormat:@"(assignatura == %@ && tema == %@)", self.assignaturaEliminar, self.temaEliminar];
    
    [request12 setPredicate:predicate12];
    NSError*error22;
    NSArray*matchingData12=[self.managedObjectContext221 executeFetchRequest:request12 error:&error22];
    NSLog(@"%@%lu", @"Hem borrat apunts: ", (unsigned long)matchingData12.count);
    if (matchingData12.count>0){
        for (int i=0;i<matchingData12.count;i++){
            NSManagedObject*missatgeBorrar=[matchingData12 objectAtIndex:i];
            [self.managedObjectContext221 deleteObject:missatgeBorrar];
            NSError*error33;
            if (![self.managedObjectContext221 save:&error33]){
                
                
            }
        }
    }
    
}


-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    UITableViewCell*cell=[self.taulaTemes cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    self.anarTema=[[NSArray alloc]initWithObjects:[self.arrayTemes objectAtIndex:0],[self.arrayTemes objectAtIndex:(indexPath.row + 1)] ,nil];
    //self.anarTema=[self.arrayTemes objectAtIndex:(indexPath.row + 1)];
    NSLog(@"%@%@%@%@",@"Anar a tema: ",[self.anarTema objectAtIndex:0],@" ",[self.anarTema objectAtIndex:1]);
    [self anarDetall];
}

- (IBAction)enrere:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)temaNou:(id)sender {
    self.nomAssignatura=@"";
    self.telInfo=[[UITextField alloc]initWithFrame:CGRectMake(10,10,280,44)];
    self.telInfo.text=@"";
    //self.nouValor=@" ";
    self.telInfo.keyboardType=UIKeyboardTypeNumberPad;
    //self.nouValor=@"nom";
    self.telInfo.placeholder=NSLocalizedString(@"Tema",);
    self.telInfo.keyboardType=UIKeyboardTypeDefault;
    self.telInfo.delegate=self;
    self.telInfo.backgroundColor=[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1];
    self.telInfo.layer.cornerRadius=8;
    self.telInfo.layer.masksToBounds=YES;
    self.telInfo.textAlignment=NSTextAlignmentCenter;
    //self.telInfo.textColor=[UIColor colorWithRed:rojoLletra/255.0 green:verdeLletra/255.0 blue:azulLletra/255.0 alpha:1];
    //self.telInfo.font=[UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:20];
    CGFloat tamanyPantalla=[[UIScreen mainScreen] bounds].size.height;
    CGFloat tamanyPantalla2=[[UIScreen mainScreen] bounds].size.width;
    NSLog(@"%f",tamanyPantalla);
    NSLog(@"%f",tamanyPantalla2);
    self.infoInteres=[[UIView alloc]initWithFrame:CGRectMake((tamanyPantalla2-300)/2,tamanyPantalla-450,300,120)];
    self.infoInteres.backgroundColor=[UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1];
    self.infoInteres.layer.cornerRadius=15;
    self.infoInteres.layer.masksToBounds=YES;
    UIButton*accioCancelar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioCancelar setTitle:NSLocalizedString(@"Cancel·lar",) forState:UIControlStateNormal];
    [accioCancelar addTarget:self action:@selector(cancelar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioCancelar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioCancelar setFrame:CGRectMake(10,70,120,24)];
    UIButton*accioGuardar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioGuardar setTitle:NSLocalizedString(@"Guardar",) forState:UIControlStateNormal];
    [accioGuardar addTarget:self action:@selector(guardar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioGuardar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioGuardar setFrame:CGRectMake(170,70,120,24)];
    [self.infoInteres addSubview:accioGuardar];
    [self.infoInteres addSubview:accioCancelar];
    [self.infoInteres addSubview:self.telInfo];
    [[self view] addSubview:self.infoInteres];
}

-(void)guardar:(NSString*)valorGuardar{
    if([self.telInfo.text length]>0){
    self.nomAssignatura=self.telInfo.text;
    [self.infoInteres removeFromSuperview];
    NSLog(@"%@%@",@"Valor nomTema: ",self.nomAssignatura);
    [self contactarServidor];
    //[self carpetaNova];
    }
}

-(void)carpetaNova{
    [self.arrayTemes addObject:self.nomAssignatura];
    [self.arrayAssignatures replaceObjectAtIndex:a withObject:self.arrayTemes];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
    [defaults3vc synchronize];
    [self.taulaTemes reloadData];
    NSLog(@"Carpeta creada");
}

-(void)cancelar:(NSString*)valorGuardar{
    self.nomAssignatura=@"";
    [self.infoInteres removeFromSuperview];
}

-(BOOL)textFieldShouldReturn:(UITextField*)textField{
    [self.telInfo resignFirstResponder];
    return YES;
}

-(void)contactarServidor{
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    NSString*assignatura=[self.arrayTemes objectAtIndex:0];
    NSString*usuari=[defaults3vc objectForKey:@"usuari"];
    NSString*tema=self.nomAssignatura;
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  assignatura,@"assignatura",
                                  usuari,@"usuari",
                                  tema,@"tema",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/tema.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if ([newStr isEqualToString:@"ok"]){
            dispatch_async (dispatch_get_main_queue (),^{
                [self carpetaNova];
            });
        }
    }];
}

-(void)anarDetall{
    [self performSegueWithIdentifier:@"anarDetall" sender:self];
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"anarDetall"]){
        NSLog(@"%@%@",@"Assignatura: ",[self.anarTema objectAtIndex:0]);
        NSLog(@"%@%@",@"Tema: ",[self.anarTema objectAtIndex:1]);
        [[segue destinationViewController] setDadesRebudes:self.anarTema];
    }
}

@end
