//
//  Apunt+CoreDataClass.m
//  ÉtoimosApp
//
//  Created by Miquel Perera on 27/7/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import "Apunt+CoreDataClass.h"

@implementation Apunt

@end
