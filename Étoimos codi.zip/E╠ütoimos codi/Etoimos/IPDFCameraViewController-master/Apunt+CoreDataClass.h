//
//  Apunt+CoreDataClass.h
//  ÉtoimosApp
//
//  Created by Miquel Perera on 27/7/17.
//  Copyright © 2017 Maximilian Mackh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Apunt : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Apunt+CoreDataProperties.h"
