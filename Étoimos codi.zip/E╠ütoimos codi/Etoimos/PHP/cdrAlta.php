<?php
	$host = "qyx339.rep.cat";
	$db = "qyx339";
	$user2 = "qyx340";
	$pass2 = "Camela2011";
	$connection = mysqli_connect($host,$user2,$pass2);
	if(!$connection){
       die ('Conexio fallat: ' . mysqli_connect_error());
   	}
	$dbconnect = mysqli_select_db($connection,$db);
	if(!$dbconnect){
        die ('No BDD: ' . mysqli_error($connection));
    }
	$Ip = $_SERVER["REMOTE_ADDR"];
	$nom = "YO"; 
	$data = date_create()->format('Y-m-d H:i:s');
	$convidas = "3";
	$observaciones= "Hola que tal";
    $query = "SELECT * FROM control WHERE nom = '$nom' LIMIT 1";
   	$results = mysqli_query($connection,$query) or die(mysqli_error($connection));
   	$numResults = mysqli_num_rows($results);
	if ($numResults > 0) {
		echo "existeix";
	} else {
		$sql = "INSERT INTO control (Ip,data,nom,convidas,observaciones) value ('$Ip','$data','$nom','$convidas','$observaciones')";
    	$retval = mysqli_query($connection,$sql);
    	if (!$retval){
			die ('No hem pogut incorporar dates: ' . mysqli_error($connection));
    	}else{
    		echo "Inserit";
    	}
	}
	mysqli_close($connection);
?>