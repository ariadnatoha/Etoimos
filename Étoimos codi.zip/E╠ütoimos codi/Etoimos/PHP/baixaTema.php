<?php
	$gestor = fopen("php://input", "rb");
   	$contenido = stream_get_contents($gestor);
   	$request = json_decode($contenido, true);
   	fclose($gestor);
   	$assignatura = $request['assignatura'];
   	$tema = $request['tema'];
   	$usuari = $request['usuari'];
   	$dir = "/var/www/vhost/ges-work.com/home/data/etoimos/".$usuari."/".$assignatura."/".$tema."/";
   	$contents = scandir($dir);
   	if (count($contents) > 0) { 
       	for ($i = 0; $i < count($contents); $i++){ 
	 		$assignatures = substr($contents[$i],0);
	 		$arrayNoDirs = array(".","..","...");
	 		if (!in_array($assignatures, $arrayNoDirs)){
	 			unlink ($dir.$assignatures);
			}
		} 		
	}
	rmdir ($dir);
   	echo "ok";
?>