//
//  ViewController2.h
//  Étoimos
//
//  Created by Miquel Perera on 12/6/17.
//  Copyright © 2017 Miquel Toha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end
