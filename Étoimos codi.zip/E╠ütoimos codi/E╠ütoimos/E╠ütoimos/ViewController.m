//
//  ViewController.m
//  Étoimos
//
//  Created by Miquel Perera on 12/6/17.
//  Copyright © 2017 Miquel Toha. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize imagePicker;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)ferFptp:(id)sender {
    [self ubicarImagePicker];
}

- (IBAction)canvi:(id)sender {
    [self performSegueWithIdentifier:@"uadis" sender:self];
}

-(void)ubicarImagePicker{
    self.imagePicker=[[UIImagePickerController alloc]init];
    self.imagePicker.delegate=self;
    self.imagePicker.sourceType=UIImagePickerControllerSourceTypeCamera;
    //self.imagePicker.mediaTypes=[[NSArray alloc]initWithObjects:(NSString*)kUTTypeImage,nil];
    self.imagePicker.mediaTypes=[UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
    self.imagePicker.videoQuality=UIImagePickerControllerQualityTypeMedium;
    self.imagePicker.showsCameraControls=YES;
    [self presentViewController:self.imagePicker animated:NO completion:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController*)picker{
    [self.imagePicker dismissViewControllerAnimated:NO completion:nil];
    [self.imagePicker removeFromParentViewController];
    [self enviarServidor];
}

-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary*)info{
    NSString*video2=[info objectForKey:UIImagePickerControllerMediaType];
    [self enviarServidor];
    if([video2 isEqualToString:@"public.movie"]){
        NSURL*tempFile=(NSURL*)[info objectForKey:@"UIImagePickerControllerMediaURL"];
        NSURL*mediaType=(NSURL*)[info objectForKey:@"UIImagePickerControllerReferenceURL"];
        NSURL*adrecaNovaMulti1=(NSURL*)[info objectForKey:@"UIImagePickerControllerReferenceURL"];
        NSString*adrecaNovaMulti=[adrecaNovaMulti1 absoluteString];
        /*
        self..moviePlayer=[[MPMoviePlayerController alloc]initWithContentURL:tempFile];
        self.moviePlayer.shouldAutoplay=NO;
        self.dirVideo=[self.mediaType absoluteString];
        if (self.guardarRodet && self.guardarApli){
            ALAssetsLibrary*library=[[ALAssetsLibrary alloc]init];
            [library writeVideoAtPathToSavedPhotosAlbum:self.tempFile completionBlock:^(NSURL*assetURL,NSError*error){
                if (error){
                    
                }else{
                    self.adrecaNovaMulti=[assetURL absoluteString];
                    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSUserDefaultsDidChangeNotification object:nil];
                    NSUserDefaults*defaults126rw=[NSUserDefaults standardUserDefaults];
                    [defaults126rw setObject:self.adrecaNovaMulti forKey:@"guardatURL"];
                    [defaults126rw synchronize];
                    self.timerComunicats=[NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(jaComunicat2) userInfo:nil repeats:NO];
                    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(afegirMissatge) name:NSUserDefaultsDidChangeNotification object:nil];
                }
            }];
        }
        NSString*dirVideo2=[self.tempFile path];
        self.videoData=[NSData dataWithContentsOfFile:dirVideo2];
        AVURLAsset*asset=[[AVURLAsset alloc]initWithURL:self.tempFile options:nil];
        AVAssetImageGenerator*generateImg=[[AVAssetImageGenerator alloc] initWithAsset:asset];
        NSError*error=NULL;
        CMTime time=CMTimeMake(1,65);
        CGImageRef refImg=[generateImg copyCGImageAtTime:time actualTime:NULL error:&error];
        NSTimeInterval temps=CMTimeGetSeconds(asset.duration);
        int seconds=(int)temps % 60;
        int minutes=temps / 60;
        self.durada=[NSString stringWithFormat:@"%02d:%02d",minutes,seconds];
        if (!self.guardarRodet){
            self.imatge2=[UIImage imageWithCGImage:refImg scale:1.0 orientation:UIImageOrientationLeft];
        }else{
            self.imatge2=[[UIImage alloc] initWithCGImage:refImg];
        }
        float x=self.imatge2.size.height;
        float y=self.imatge2.size.width;
        self.resolucio=[NSString stringWithFormat:@"%0.f%@%0.f",x, @" x ",y];
        CGSize targetSize=CGSizeMake(200,150);
        UIGraphicsBeginImageContext(targetSize);
        CGRect thumbnailRect=CGRectMake(0,0,0,0);
        thumbnailRect.origin=CGPointMake(0.0,0.0);
        thumbnailRect.size.width =targetSize.width;
        thumbnailRect.size.height=targetSize.height;
        [self.imatge2 drawInRect:thumbnailRect];
        self.imatge2=UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        */
    }
    if([video2 isEqualToString:@"public.image"]){
        /*
        self.esFoto=YES;
        self.imatge2=[info objectForKey:UIImagePickerControllerOriginalImage];
        self.tempFile=(NSURL*)[info objectForKey:@"UIImagePickerControllerMediaURL"];
        NSURL*adrecaNovaMulti1=(NSURL*)[info objectForKey:@"UIImagePickerControllerReferenceURL"];
        self.adrecaNovaMulti=[adrecaNovaMulti1 absoluteString];
        if (self.guardarRodet && self.guardarApli){
            self.guardarRodet=NO;
            ALAssetsLibrary*library=[[ALAssetsLibrary alloc] init];
            [library writeImageToSavedPhotosAlbum:[self.imatge2 CGImage] orientation:(ALAssetOrientation)[self.imatge2 imageOrientation] completionBlock:^(NSURL*assetURL,NSError*error){
                if (error){
                    
                }else{
                    self.adrecaNovaMulti=[assetURL absoluteString];
                    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSUserDefaultsDidChangeNotification object:nil];
                    NSUserDefaults*defaults126eq=[NSUserDefaults standardUserDefaults];
                    [defaults126eq setObject:self.adrecaNovaMulti forKey:@"guardatURL"];
                    [defaults126eq synchronize];
                    self.timerComunicats=[NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(jaComunicat2) userInfo:nil repeats:NO];
                    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(afegirMissatge) name:NSUserDefaultsDidChangeNotification object:nil];
                }
            }];
        }
        if (self.novaFoto){
            self.novaFoto=NO;
            float alcada=self.imatge2.size.height;
            float amplada=self.imatge2.size.width;
            float proporcio=0.0;
            if (amplada > alcada){
                proporcio=(1088*alcada)/amplada;
                amplada=1088;
                alcada=proporcio;
            }else{
                proporcio=(816*amplada)/alcada;
                alcada=816;
                amplada=proporcio;
            }
            CGSize targetSize=CGSizeMake(amplada,alcada);
            UIGraphicsBeginImageContext(targetSize);
            CGRect thumbnailRect=CGRectMake(0,0,0,0);
            thumbnailRect.origin=CGPointMake(0.0,0.0);
            thumbnailRect.size.width=targetSize.width;
            thumbnailRect.size.height=targetSize.height;
            [self.imatge2 drawInRect:thumbnailRect];
            self.imatge2=UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
    */
    }
    [self.imagePicker dismissViewControllerAnimated:NO completion:nil];
    [self.imagePicker removeFromParentViewController];
}

-(void)enviarServidor{
    NSString*vista2=@"Benvinguts a clase";
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  vista2,@"meuTel",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/tt.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
    }];
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if([[segue identifier] isEqualToString:@"uadis"]){
        [segue destinationViewController];
    }
}

@end
