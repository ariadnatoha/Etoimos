//
//  ViewController.h
//  Étoimos
//
//  Created by Miquel Perera on 12/6/17.
//  Copyright © 2017 Miquel Toha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property (nonatomic,retain) UIImagePickerController*imagePicker;

- (IBAction)ferFptp:(id)sender;
- (IBAction)canvi:(id)sender;

@end

