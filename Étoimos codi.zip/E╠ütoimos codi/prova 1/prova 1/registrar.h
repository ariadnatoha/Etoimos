//
//  registrar.h
//  prova 1
//
//  Created by ignasi on 16/6/17.
//  Copyright © 2017 ignasi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface registrar : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *nomUsuari;
@property (weak, nonatomic) IBOutlet UITextField *correu;
@property (weak, nonatomic) IBOutlet UITextField *contrasenya1;
@property (weak, nonatomic) IBOutlet UITextField *contrasenya2;
- (IBAction)enrere:(id)sender;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loading;

@end
