//
//  Preferencies.h
//  prova 1
//
//  Created by ignasi on 19/6/17.
//  Copyright © 2017 ignasi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Preferencies : UITableViewController
@property (strong,nonatomic) NSArray*seccio0;
@property (strong,nonatomic) NSArray*seccio1;
@property (strong,nonatomic) NSArray*seccio2;
@property (strong,nonatomic) NSArray*seccio3;
@property (strong,nonatomic) NSArray*seccio4;
@property (strong,nonatomic) NSArray*seccio5;
@property (strong,nonatomic) NSArray*seccio6;
@property (strong,nonatomic) NSArray*seccio7;
@property (strong,nonatomic) NSArray*seccio8;
@property (strong,nonatomic) NSArray*seccio9;
@property (strong,nonatomic) NSArray*seccio10;
@property BOOL eliminar;
@property BOOL vaigOcult;
@property BOOL eliminant;
@end
