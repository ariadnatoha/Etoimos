//
//  Preferencies.m
//  prova 1
//
//  Created by ignasi on 19/6/17.
//  Copyright © 2017 ignasi. All rights reserved.
//

#import "Preferencies.h"

@interface Preferencies ()

@end

@implementation Preferencies
@synthesize vaigOcult,seccio0,seccio1,seccio2,seccio3,seccio4,seccio5,seccio6,seccio7,seccio9,seccio8,seccio10,eliminar,eliminant;
- (void)viewDidLoad {
    [super viewDidLoad];
    NSString*Grup1=NSLocalizedString(@"Perfil",);
    NSString*Grup2=NSLocalizedString(@"Estado",);
    NSString*Grup3=NSLocalizedString(@"Privacidad",);
    NSString*Grup4=NSLocalizedString(@"Chat oculto",);
    NSString*Grup5=NSLocalizedString(@"Ajustes de chat",);
    NSString*Grup6=NSLocalizedString(@"Recomendar",);
    NSString*Grup7=NSLocalizedString(@"Opciones de guardado",);
    NSString*Grup8=NSLocalizedString(@"Ordenar agenda",);
    NSString*Grup9=NSLocalizedString(@"Valorar SpeakApp",);
    NSString*Grup10=NSLocalizedString(@"Notificaciones y sonidos",);
    NSString*Grup12=NSLocalizedString(@"Pulsometro",);
    NSString*Grup13=NSLocalizedString(@"Tensiometro",);
    NSString*Grup14=NSLocalizedString(@"Temperatura",);
    NSString*Grup15=NSLocalizedString(@"Informacion Medica",);
    NSString*Grup17=NSLocalizedString(@"Contactar con SpeakApp",);
    NSString*Grup18=NSLocalizedString(@"Acuerdo de licencia",);
    NSString*Grup19=NSLocalizedString(@"Ayuda",);
    NSString*Grup20=NSLocalizedString(@"Asociar dispositivo GPS",);
    NSString*Grup21=NSLocalizedString(@"Zonas de Seguridad",);
    NSString*Grup22=NSLocalizedString(@"Premium",);
    NSString*Grup23=NSLocalizedString(@"Video tutoriales",);
    NSString*Grup24=NSLocalizedString(@"Ver dispositivos compatibles",);
    NSString*Grup25=NSLocalizedString(@"Eliminar cuenta",);
    self.seccio0=[[NSArray alloc]initWithObjects:Grup1,Grup2,Grup3,Grup10,Grup7,Grup8,nil];
    self.seccio1=[[NSArray alloc]initWithObjects:Grup15,Grup12,Grup13,Grup14,nil];
    self.seccio2=[[NSArray alloc]initWithObjects:Grup5,Grup4,nil];
    self.seccio3=[[NSArray alloc]initWithObjects:Grup9,Grup6,nil];
    self.seccio4=[[NSArray alloc]initWithObjects:Grup17,nil];
    self.seccio5=[[NSArray alloc]initWithObjects:Grup18,nil];
    self.seccio6=[[NSArray alloc]initWithObjects:Grup19,nil];
    self.seccio7=[[NSArray alloc]initWithObjects:Grup20,Grup21,Grup24,nil];
    self.seccio8=[[NSArray alloc]initWithObjects:Grup22,nil];
    self.seccio9=[[NSArray alloc]initWithObjects:Grup23,nil];
    self.seccio10=[[NSArray alloc]initWithObjects:Grup25,nil];
    [self.tableView reloadData];
    self.vaigOcult=NO;

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView{
    return 11;
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0){
        return self.seccio0.count;
    }else
        if (section==3){
            return self.seccio1.count;
        }else
            if (section==4){
                return self.seccio2.count;
            }else
                if (section==5){
                    return self.seccio3.count;
                }else
                    if (section==6){
                        return self.seccio4.count;
                    }else
                        if (section==7){
                            return self.seccio5.count;
                        }else
                            if (section==8){
                                return self.seccio6.count;
                            }else
                                if (section==2){
                                    return self.seccio7.count;
                                }else
                                    if (section==1){
                                        return self.seccio8.count;
                                    }else
                                        if (section==9) {
                                            return self.seccio9.count;
                                        }else
                                            if (section==10) {
                                                return self.seccio10.count;
                                            }else
                                                return 0;
}

-(CGFloat)tableView:(UITableView*)tableView heightForHeaderInSection:(NSInteger)section{
    return 20;
}

-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 51;
}
-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString*CellIdentifier=@"Cell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    NSString*nom1=@"";
    if (indexPath.section==0){
        nom1=[self.seccio0 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==3){
        nom1=[self.seccio1 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==4){
        nom1=[self.seccio2 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==5){
        nom1=[self.seccio3 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==6){
        nom1=[self.seccio4 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==7){
        nom1=[self.seccio5 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==8){
        nom1=[self.seccio6 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==2){
        nom1=[self.seccio7 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==1){
        nom1=[self.seccio8 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==9){
        nom1=[self.seccio9 objectAtIndex:indexPath.row];
    }
    if (indexPath.section==10){
        nom1=[self.seccio10 objectAtIndex:indexPath.row];
    }
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    UIFont*fontBold=[UIFont fontWithName:@"SF Pro Display" size:20];
    NSMutableAttributedString*string=[[NSMutableAttributedString alloc]initWithString:nom1];
    [string addAttribute:NSFontAttributeName value:fontBold range:NSMakeRange(0,[nom1 length])];
    cell.textLabel.attributedText=string;
    
    float rojo=0;
    float verde=0;
    float azul=0;
    NSString*vermell=@"";
    NSString*verd=@"";
    NSString*blau=@"";
    NSUserDefaults*defaultspr43=[NSUserDefaults standardUserDefaults];
    vermell=[defaultspr43 objectForKey:@"fonsR"];
    rojo=[vermell floatValue];
    verd=[defaultspr43 objectForKey:@"fonsG"];
    verde=[verd floatValue];
    blau=[defaultspr43 objectForKey:@"fonsB"];
    azul=[blau floatValue];
    //cell.backgroundColor=[UIColor colorWithRed:rojo/255.0 green:verde/255.0 blue:azul/255.0 alpha:1];
    vermell=[defaultspr43 objectForKey:@"lletraIntR"];
    rojo=[vermell floatValue];
    verd=[defaultspr43 objectForKey:@"lletraIntG"];
    verde=[verd floatValue];
    blau=[defaultspr43 objectForKey:@"lletraIntB"];
    azul=[blau floatValue];
    if (indexPath.section==10){
        //cell.textLabel.textColor=[UIColor colorWithRed:255.0/255.0 green:0.0/255.0 blue:0.0/255.0 alpha:1];
    }else{
        //cell.textLabel.textColor=[UIColor colorWithRed:rojo/255.0 green:verde/255.0 blue:azul/255.0 alpha:1];
    }
    return cell;
}

-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    if (!self.eliminant){
        NSString*Grup1=NSLocalizedString(@"Perfil",);
        NSString*Grup2=NSLocalizedString(@"Estado",);
        NSString*Grup3=NSLocalizedString(@"Privacidad",);
        NSString*Grup4=NSLocalizedString(@"Chat oculto",);
        NSString*Grup5=NSLocalizedString(@"Ajustes de chat",);
        NSString*Grup6=NSLocalizedString(@"Recomendar",);
        NSString*Grup7=NSLocalizedString(@"Opciones de guardado",);
        NSString*Grup8=NSLocalizedString(@"Ordenar agenda",);
        NSString*Grup9=NSLocalizedString(@"Valorar SpeakApp",);
        NSString*Grup10=NSLocalizedString(@"Notificaciones y sonidos",);
        NSString*Grup12=NSLocalizedString(@"Pulsometro",);
        NSString*Grup13=NSLocalizedString(@"Tensiometro",);
        NSString*Grup14=NSLocalizedString(@"Temperatura",);
        NSString*Grup15=NSLocalizedString(@"Informacion Medica",);
        NSString*Grup17=NSLocalizedString(@"Contactar con SpeakApp",);
        NSString*Grup18=NSLocalizedString(@"Acuerdo de licencia",);
        NSString*Grup19=NSLocalizedString(@"Ayuda",);
        NSString*Grup20=NSLocalizedString(@"Asociar dispositivo GPS",);
        NSString*Grup21=NSLocalizedString(@"Zonas de Seguridad",);
        NSString*Grup22=NSLocalizedString(@"Premium",);
        NSString*Grup23=NSLocalizedString(@"Video tutoriales",);
        NSString*Grup24=NSLocalizedString(@"Ver dispositivos compatibles",);
        NSString*Grup25=NSLocalizedString(@"Eliminar cuenta",);
        NSString*celaPremuda=@"";
        UITableViewCell*cell=[self.tableView cellForRowAtIndexPath:indexPath];
        if ([cell.reuseIdentifier isEqualToString:@"Cell"]){
            if (indexPath.section==0){
                celaPremuda=[self.seccio0 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==3){
                celaPremuda=[self.seccio1 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==4){
                celaPremuda=[self.seccio2 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==5){
                celaPremuda=[self.seccio3 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==6){
                celaPremuda=[self.seccio4 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==7){
                celaPremuda=[self.seccio5 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==8){
                celaPremuda=[self.seccio6 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==2){
                celaPremuda=[self.seccio7 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==1){
                celaPremuda=[self.seccio8 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==9){
                celaPremuda=[self.seccio9 objectAtIndex:indexPath.row];
            }
            if (indexPath.section==10){
                celaPremuda=[self.seccio10 objectAtIndex:indexPath.row];
            }
        }
        if ([celaPremuda isEqualToString:Grup1]){
            [self performSegueWithIdentifier:@"configPerfil" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup2]){
            [self performSegueWithIdentifier:@"configEstado" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup3]){
            [self performSegueWithIdentifier:@"opcionsPriv" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup4]){
            [self performSegueWithIdentifier:@"modoOculto" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup5]){
            [self performSegueWithIdentifier:@"confEstils" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup6]){
            [self performSegueWithIdentifier:@"recomanar" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup7]){
            [self performSegueWithIdentifier:@"configGuardar" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup8]){
            [self performSegueWithIdentifier:@"configAgenda" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup9]){
            [cell setSelected:NO];
            //[self valorar];
        }
        if ([celaPremuda isEqualToString:Grup10]){
            [self performSegueWithIdentifier:@"notifSons" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup12]){
            [self performSegueWithIdentifier:@"pulsometre" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup13]){
            [self performSegueWithIdentifier:@"tensiometre" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup14]){
            [self performSegueWithIdentifier:@"temperatura" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup15]){
            [self performSegueWithIdentifier:@"infoMedica" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup17]){
            //[self mail];
        }
        if ([celaPremuda isEqualToString:Grup18]){
            [self performSegueWithIdentifier:@"politicaPrivacitat" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup19]){
            [self performSegueWithIdentifier:@"ajuda" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup20]){
            [self performSegueWithIdentifier:@"vendaDisp" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup21]){
            [self performSegueWithIdentifier:@"llistaGeofence" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup22]){
            [self performSegueWithIdentifier:@"p9" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup23]){
            [self performSegueWithIdentifier:@"videos" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup24]){
            [self performSegueWithIdentifier:@"detallDisps" sender:cell];
        }
        if ([celaPremuda isEqualToString:Grup25]){
            //[self eliminarCompte];
        }
    }
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    self.vaigOcult=NO;
    /*
    if ([[segue identifier] isEqualToString:@"configAgenda"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configPerfil"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"opcionsPriv"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configNotif"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configFonsPantalla"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configTamanyLletra"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configGuardar"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configBloquejats"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configAccesCodi"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configEspecials"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"fonsXat"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"recomanar"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configEstado"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"modoOculto"]){
        self.vaigOcult=YES;
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configLocalitzacio"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"notifSons"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"meuPerfil"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"infoMedica"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"pulsometre"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"tensiometre"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"temperatura"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"politicaPrivacitat"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"ajuda"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"configLog"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"vendaDisp"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"llistaGeofence"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"p9"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"videos"]){
        [segue destinationViewController];
    }
    if ([[segue identifier] isEqualToString:@"detallDisps"]){
        [segue destinationViewController];
    }
     */
}


@end
