//
//  registrar.m
//  prova 1
//
//  Created by ignasi on 16/6/17.
//  Copyright © 2017 ignasi. All rights reserved.
//

#import "registrar.h"

@interface registrar ()

@end

@implementation registrar
@synthesize nomUsuari,correu,contrasenya1,contrasenya2,loading;

- (void)viewDidLoad {
    [super viewDidLoad];
    nomUsuari.delegate=self;
    correu.delegate=self;
    contrasenya1.delegate=self;
    contrasenya2.delegate=self;
    loading.hidden=true;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSLog(@"%@%@",@"Return: ",textField);
    [nomUsuari resignFirstResponder];
    [correu resignFirstResponder];
    [contrasenya1 resignFirstResponder];
    [contrasenya2 resignFirstResponder];
    if (textField == contrasenya2) {
        [self comprovacioUsuari];
    }
    return YES;
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    NSLog(@"%@%@",@"End Editing: ",textField);
    [nomUsuari resignFirstResponder];
    [correu resignFirstResponder];
    [contrasenya1 resignFirstResponder];
    [contrasenya2 resignFirstResponder];
    return YES;
}

-(void)comprovacioUsuari{
    
    BOOL contrassenya = NO;
    BOOL tenimUsuari = NO;
    BOOL tenimMail = NO;
    if ([contrasenya1.text length] > 5) {
        NSLog(@"%@%lu",@"Longitud correcta, es: ",[contrasenya1.text length]);
        if ([contrasenya1.text isEqualToString:contrasenya2.text]){
            NSLog(@"Log coincideixen");
            contrassenya= YES;
        }else{
            NSLog(@"Log No coincideixen");
            UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"No coincideixen",) message:NSLocalizedString(@"Torna a entrar contrasenyes",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
            [imatgeGuardada show];
        }
    }else{
        NSLog(@"%@%lu",@"Longitud no es correcta, es: ",[contrasenya1.text length]);
        UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Massa curta",) message:NSLocalizedString(@"Torna a entrar contrasenyes",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
        [imatgeGuardada show];
    }
    if ([nomUsuari.text length] > 0) {
        tenimUsuari = YES;
    }
    if ([correu.text length] > 0) {
        tenimMail = YES;
    }
    if (contrassenya && tenimMail && tenimUsuari) {
        [self comunicarServidor];
    }
}

-(void)comunicarServidor{
    NSLog(@"Anem a contactar amb Servidor");
    loading.hidden=false;
    [loading startAnimating];
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  nomUsuari.text,@"usuari",
                                  contrasenya1.text,@"contrassenya",
                                  correu.text,@"mail",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/alta.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        dispatch_async(dispatch_get_main_queue(), ^{
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"%@",newStr);
            [loading stopAnimating];
            loading.hidden=true;
        });
        
    }];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

- (IBAction)accio:(id)sender {
    [nomUsuari resignFirstResponder];
    [correu resignFirstResponder];
    [contrasenya1 resignFirstResponder];
    [contrasenya2 resignFirstResponder];
    [self comprovacioUsuari];
}

- (IBAction)enrere:(id)sender {
    
}

@end
