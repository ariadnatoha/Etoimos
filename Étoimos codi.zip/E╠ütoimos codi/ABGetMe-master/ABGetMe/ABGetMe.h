#import <AddressBook/AddressBook.h>

ABRecordRef ABGetMe(ABAddressBookRef addressBook);
