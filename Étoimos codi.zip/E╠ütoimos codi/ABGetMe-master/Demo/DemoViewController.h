//
//  ViewController.h
//  ABGetMe
//
//  Created by Cédric Luthi on 13.01.12.
//  Copyright (c) 2012 Cédric Luthi. All rights reserved.
//

@interface DemoViewController : UIViewController

- (IBAction) me;

@end
