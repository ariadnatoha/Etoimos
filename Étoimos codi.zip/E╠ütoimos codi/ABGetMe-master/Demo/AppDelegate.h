//
//  AppDelegate.h
//  ABGetMe
//
//  Created by Cédric Luthi on 13.01.12.
//  Copyright (c) 2012 Cédric Luthi. All rights reserved.
//

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
