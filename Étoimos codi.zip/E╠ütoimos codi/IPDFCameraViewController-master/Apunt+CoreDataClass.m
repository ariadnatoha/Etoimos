//
//  Apunt+CoreDataClass.m
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 27/7/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import "Apunt+CoreDataClass.h"

@implementation Apunt

@end
