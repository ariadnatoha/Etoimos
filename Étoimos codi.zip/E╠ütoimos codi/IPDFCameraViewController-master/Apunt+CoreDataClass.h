//
//  Apunt+CoreDataClass.h
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 27/7/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Apunt : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Apunt+CoreDataProperties.h"
