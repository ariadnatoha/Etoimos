//
//  Configuracio.h
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 25/7/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Configuracio : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *taulaConfiguracio;
@property (nonatomic, retain) NSMutableArray *arrayConfiguracio;

- (IBAction)enrere:(id)sender;




@end
