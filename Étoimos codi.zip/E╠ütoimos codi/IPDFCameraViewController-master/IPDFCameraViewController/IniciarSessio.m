//
//  IniciarSessio.m
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 2/7/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import "IniciarSessio.h"

@interface IniciarSessio ()

@end

@implementation IniciarSessio
@synthesize Usuari,Clau,Usuari2,Clau2,Resposta;

//Quan iniciem sessió s'han de recuperar les dades del servidor

- (void)viewDidLoad {
    [super viewDidLoad];
    self.Resposta=@"";
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    NSLog(@"%@%@",@"End Editing: ",textField);
    [Usuari resignFirstResponder];
    [Clau resignFirstResponder];
    return YES;
}

-(void)comunicarServidor{
    NSLog(@"Anem a contactar amb Servidor");
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  Usuari.text,@"usuari",
                                  Clau.text,@"contrassenya",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/inici.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if (data && !error1) {
            [self rebudesInstruccions:data];
        }
    }];
}

-(void)rebudesInstruccions:(NSData*)dataRebuda{
    NSString*newStr=[[NSString alloc]initWithData:dataRebuda encoding:NSUTF8StringEncoding];
    if (newStr.length>5){
        NSString*ltr=[NSString stringWithFormat:@"%c",[newStr characterAtIndex:0]];
        if ([ltr isEqualToString:@","]){
            newStr=[newStr substringFromIndex:1];
        }
        newStr=[NSString stringWithFormat:@"%@%@%@",@"[",newStr,@"]"];
        NSError*err;
        NSArray*array=[NSJSONSerialization JSONObjectWithData:[newStr dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:&err];
        if (array.count>0){
            NSDictionary*instruccioRebuda=[array objectAtIndex:0];
            if ([[instruccioRebuda objectForKey:@"instruccio"] isEqualToString:@"24"]){
                NSDictionary*arrayAssignatures=[instruccioRebuda objectForKey:@"carpetes"];
                NSLog(@"%@%lu",@"Rebudes assignatures: ",(unsigned long)arrayAssignatures.count);
                if (arrayAssignatures.count >0) {
                    NSMutableArray*arrayAssignatures2=[[NSMutableArray alloc] init];
                    for (int i=0; i<arrayAssignatures.count; i++) {
                        NSString*clau=[NSString stringWithFormat:@"%d",i];
                        NSDictionary*temes=[arrayAssignatures objectForKey:clau];
                        if (temes.count>0) {
                            NSLog(@"%@%@",@"Assignatura: ",[temes objectForKey:@"0"]);
                            //Crear mutableArray amb ssignatura a Lloc 0
                            NSMutableArray*assignatura=[[NSMutableArray alloc] init];
                            [assignatura addObject:[temes objectForKey:@"0"]];
                            if (temes.count>1) {
                                for (int j=1; j<temes.count; j++) {
                                    NSString*clau2=[NSString stringWithFormat:@"%d",j];
                                    NSLog(@"%@%@",@"Tema: ",[temes objectForKey:clau2]);
                                    //Afegir a l'Array el Tema
                                    [assignatura addObject:[temes objectForKey:clau2]];
                                }
                            }
                            //Guardar el Mutable array
                            [arrayAssignatures2 addObject:assignatura];
                        }
                    }
                    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
                    [defaults3vc setObject:arrayAssignatures2 forKey:@"Assignatures"];
                    [defaults3vc synchronize];
                }
                [self endavant];
            }else{
                if ([[instruccioRebuda objectForKey:@"instruccio"] isEqualToString:@"35"]) {
                    [self usuariInexistent];
                }else{
                    if ([[instruccioRebuda objectForKey:@"instruccio"] isEqualToString:@"25"]) {
                        [self clauIncorrecta];
                    }
                }
            }
        }
    }
}

- (IBAction)Comença:(id)sender {
    
    self.Usuari2=Usuari.text;
    self.Clau2=Clau.text;
    [self comunicarServidor];
}

- (void) endavant {
    NSLog(@"rebut");
    self.Resposta=@"endavant";
    dispatch_async (dispatch_get_main_queue (),^{
        NSUserDefaults*usu=[NSUserDefaults standardUserDefaults];
        [usu setObject:self.Usuari2 forKey:@"usuari"];
        [usu synchronize];
        [self performSegueWithIdentifier:@"fet" sender:self];
    });
}

-(void) usuariInexistent {
    NSLog(@"usuari");
    dispatch_async (dispatch_get_main_queue (),^{
        self.Resposta=@"usuariInexistent";
        UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"L'usuari no existeix",) message:NSLocalizedString(@"Comprova que l'has escrit correctament",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
        [imatgeGuardada show];
    });
}

-(void) clauIncorrecta {
    NSLog(@"clau");
    dispatch_async (dispatch_get_main_queue (),^{
        self.Resposta=@"clauIncorrecta";
        UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Clau incorrecta",) message:NSLocalizedString(@"Comprova que l'has escrit correctament",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
        [imatgeGuardada show];
    });
}
-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"fet"]){
        [segue destinationViewController];
    }
}
@end
