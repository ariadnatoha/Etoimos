//
//  veureFoto.h
//  Étoimos
//
//  Created by Ariadna Toha on 2/9/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface veureFoto : UIViewController<UIScrollViewDelegate>{
    IBOutlet UIScrollView*scrollView;
    UIImageView*imageView;
}

@property (nonatomic,retain) UIScrollView*scrollView;
@property (nonatomic,retain) UIImageView*imageView;
@property (nonatomic,strong) UIImage*imatgeRebuda;

@end
