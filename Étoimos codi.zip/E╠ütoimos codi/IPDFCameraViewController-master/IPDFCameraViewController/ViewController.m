//
//  ViewController.m
//  IPDFCameraViewController
//
//  Created by Ariadna Toha on 11/01/15.
//  Copyright (c) 2015 Ariadna Toha. All rights reserved.
//

#import "ViewController.h"

#import "IPDFCameraViewController.h"
#import "AppDelegate.h"
#import <CoreData/CoreData.h>

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet IPDFCameraViewController *cameraViewController;
@property (weak, nonatomic) IBOutlet UIImageView *focusIndicator;
- (IBAction)focusGesture:(id)sender;

- (IBAction)captureButton:(id)sender;

@end

@implementation ViewController
@synthesize imatgeData, variesPagines, Pagines, esticEnviant, tempsImatges, imageData, ordre, dadesApunt, infoInteres, telInfo, nomAssignatura, nomTema;

#pragma mark -
#pragma mark View Lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    AppDelegate*appDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    _managedObjectContext222=[appDelegate managedObjectContext];
    self.Pagines=[[NSMutableArray alloc] init];
    variesPagines=NO;
    esticEnviant=NO;
    [self.cameraViewController setupCameraView];
    [self.cameraViewController setEnableBorderDetection:YES];
    [self.cameraViewController setCameraViewType:IPDFCameraViewTypeNormal];
    [self updateTitleLabel];
}

- (void)viewDidAppear:(BOOL)animated
{
    [self.cameraViewController start];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma mark -
#pragma mark CameraVC Actions

- (IBAction)focusGesture:(UITapGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateRecognized)
    {
        CGPoint location = [sender locationInView:self.cameraViewController];
        
        [self focusIndicatorAnimateToPoint:location];
        
        [self.cameraViewController focusAtPoint:location completionHandler:^
         {
             [self focusIndicatorAnimateToPoint:location];
         }];
    }
}

- (void)focusIndicatorAnimateToPoint:(CGPoint)targetPoint
{
    [self.focusIndicator setCenter:targetPoint];
    self.focusIndicator.alpha = 0.0;
    self.focusIndicator.hidden = NO;
    
    [UIView animateWithDuration:0.4 animations:^
    {
         self.focusIndicator.alpha = 1.0;
    }
    completion:^(BOOL finished)
    {
         [UIView animateWithDuration:0.4 animations:^
         {
             self.focusIndicator.alpha = 0.0;
         }];
     }];
}

- (IBAction)borderDetectToggle:(id)sender
{
    BOOL enable = !self.cameraViewController.isBorderDetectionEnabled;
    enable=YES;
    //[self changeButton:sender targetTitle:(enable) ? @"CROP On" : @"CROP Off" toStateEnabled:enable];
    [self changeButton:sender targetTitle:(enable) ? @" " : @" " toStateEnabled:enable];
    self.cameraViewController.enableBorderDetection = enable;
    [self updateTitleLabel];
}

- (IBAction)filterToggle:(id)sender
{
    //[self.cameraViewController setCameraViewType:(self.cameraViewController.cameraViewType == IPDFCameraViewTypeBlackAndWhite) ? IPDFCameraViewTypeNormal : IPDFCameraViewTypeBlackAndWhite];
    [self.cameraViewController setCameraViewType:IPDFCameraViewTypeNormal];
    [self updateTitleLabel];
}

- (IBAction)torchToggle:(id)sender
{
    BOOL enable = !self.cameraViewController.isTorchEnabled;
    [self changeButton:sender targetTitle:(enable) ? @"FLASH On" : @"FLASH Off" toStateEnabled:enable];
    self.cameraViewController.enableTorch = enable;
}

- (void)updateTitleLabel
{
    CATransition *animation = [CATransition animation];
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromBottom;
    animation.duration = 0.35;
    [self.titleLabel.layer addAnimation:animation forKey:@"kCATransitionFade"];
    
    //NSString *filterMode = (self.cameraViewController.cameraViewType == IPDFCameraViewTypeBlackAndWhite) ? @"TEXT FILTER" : @"COLOR FILTER";
    //self.titleLabel.text = [filterMode stringByAppendingFormat:@" | %@",(self.cameraViewController.isBorderDetectionEnabled)?@"AUTOCROP On":@"AUTOCROP Off"];
    self.titleLabel.text=@"ESCANER";
}

- (void)changeButton:(UIButton *)button targetTitle:(NSString *)title toStateEnabled:(BOOL)enabled
{
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:(enabled) ? [UIColor colorWithRed:1 green:0.81 blue:0 alpha:1] : [UIColor whiteColor] forState:UIControlStateNormal];
}


#pragma mark -
#pragma mark CameraVC Capture Image

- (IBAction)captureButton:(id)sender
{
    __weak typeof(self) weakSelf = self;
    
    [self.cameraViewController captureImageWithCompletionHander:^(NSString *imageFilePath)
    {
        UIImage*imatge= [UIImage imageWithContentsOfFile:imageFilePath];
        //UIImageView *captureImageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:imageFilePath]];
        UIImageView *captureImageView = [[UIImageView alloc] initWithImage:imatge];
        captureImageView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.7];
        captureImageView.frame = CGRectOffset(weakSelf.view.bounds, 0, -weakSelf.view.bounds.size.height);
        captureImageView.alpha = 1.0;
        captureImageView.contentMode = UIViewContentModeScaleAspectFit;
        captureImageView.userInteractionEnabled = YES;
        
        [weakSelf.view addSubview:captureImageView];
        
        UITapGestureRecognizer *dismissTap = [[UITapGestureRecognizer alloc] initWithTarget:weakSelf action:@selector(dismissPreview:)];
        [captureImageView addGestureRecognizer:dismissTap];
        
        [UIView animateWithDuration:0.7 delay:0.0 usingSpringWithDamping:0.8 initialSpringVelocity:0.7 options:UIViewAnimationOptionAllowUserInteraction animations:^
        {
            captureImageView.frame = weakSelf.view.bounds;
        } completion:nil];
        //NSLog(@"Ja temim la foto.., que faig?");
        //NSLog(@"%@%f%@%f",@"Tamany imatge: ",imatge.size.height,@" ",imatge.size.width);
        //[self enviarServidor2:imatge];
        self.imatgeData=UIImagePNGRepresentation(imatge);
        [self performSelector:@selector(opcionsFoto) withObject:nil afterDelay:1.5];
        //[self opcionsFoto];
    }];
}

-(void)opcionsFoto{
    self.ordre=@"1";
    UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Apunt escanejat",) message:NSLocalizedString(@"Què vols fer?",) delegate:self cancelButtonTitle:nil otherButtonTitles: NSLocalizedString(@"Afegir pàgina",), NSLocalizedString(@"Eliminar pàgina",), NSLocalizedString(@"Desar",), NSLocalizedString(@"Cancel·lar",),nil];
    [imatgeGuardada show];
}

-(void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if ((buttonIndex==2) && [ordre isEqualToString:@"1"]){
        NSLog(@"Clicat DESAR");
        [self enviarServidor2];
        [self quinaAssignatura];
    } else {
        if ((buttonIndex==3) && [ordre isEqualToString:@"1"]){
            NSLog(@"Clicat CANCEL");
            [self eliminarTot];
        } else {
            if ((buttonIndex==0) && [ordre isEqualToString:@"1"]){
                NSLog(@"Clicat AFEGIR");
                [self afegirPagina];
            } else{
                if ([ordre isEqualToString:@"2"] && buttonIndex!=0){
                    NSMutableArray*arrayAssignatures=[[NSMutableArray alloc] init];
                    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
                    //[defaults3vc setObject:nil forKey:@"Assignatures"];
                    //[defaults3vc synchronize];
                    if ([defaults3vc objectForKey:@"Assignatures"] ==nil) {
                        NSArray*assignatura1=[[NSArray alloc]initWithObjects:@"Filosofia", @"Presentació inicial", nil];
                        NSArray*assignatura2=[[NSArray alloc]initWithObjects:@"Català", @"Presentació inicial", nil];
                        NSArray*assignatura3=[[NSArray alloc]initWithObjects:@"Castellà", @"Presentació inicial", nil];
                        [arrayAssignatures addObject:assignatura1];
                        [arrayAssignatures addObject:assignatura2];
                        [arrayAssignatures addObject:assignatura3];
                        [defaults3vc setObject:arrayAssignatures forKey:@"Assignatures"];
                        [defaults3vc synchronize];
                    }else{
                        arrayAssignatures = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Assignatures"]];
                    }
                    NSString*assignaturaEscollida=[[arrayAssignatures objectAtIndex:buttonIndex-1] objectAtIndex:0];
                    NSLog(@"%@%@",@"Assignatura escollida: ",assignaturaEscollida);
                    [self quinTema: assignaturaEscollida];
                }else{
                    if ([ordre isEqualToString:@"3"]){
                        NSLog(@"%@%ld", @"boto clicat: ",(long)buttonIndex);
                        NSLog(@"%@%@", @"L'assignatura és: ", dadesApunt [0]);
                        NSLog(@"%@%@", @"El tema és: ", dadesApunt [buttonIndex]);
                        self.nomTema=dadesApunt [buttonIndex];
                        [self quinNom];
                    }
                }
            }
        }
    }
}



-(void)afegirPagina{
    [self.Pagines addObject:self.imatgeData];
    if (!variesPagines) {
        variesPagines=YES;
        NSLog(@"enviem algun apunt");
        [self controlServidor];
    }
    NSLog(@"%@%lu",@"numero d'imatges: ",(unsigned long)[self.Pagines count]);
    
}

-(void)eliminarTot{
    if (variesPagines){
        variesPagines=NO;
        self.Pagines=nil;
        [self cancelarEnviar];
    }
}
-(void)cancelarEnviar{
    NSLog(@"%@%lu",@"numero d'imatges: ",(unsigned long)[self.Pagines count]);
}

-(void)controlServidor{
    if (!esticEnviant && [self.Pagines count]>0){
        [self enviarServidor3];
    }
    [self.tempsImatges invalidate];
    if (variesPagines){
        self.tempsImatges=[NSTimer scheduledTimerWithTimeInterval:(0.2) target:self selector:@selector(controlServidor) userInfo:nil repeats:NO];
    }
}

-(void)enviarServidor3{
    esticEnviant=YES;
    
    UIImage*image=[[UIImage alloc] initWithData:[self.Pagines objectAtIndex:0]];
    NSLog(@"%@%f%@%f",@"Tamany imatge Original: ",image.size.height,@" ",image.size.width);
    float w=image.size.width;
    float h=image.size.height;
    int x = 2;
    if (w>100000) {
        x=6;
    }else{
        if (w>10000 && w<=100000) {
            x=3;
        }else{
            
            
        }
    }
    
    UIImage*tempImage=nil;
    CGSize targetSize=CGSizeMake(w/x,h/x);
    UIGraphicsBeginImageContext(targetSize);
    CGRect thumbnailRect=CGRectMake(0,0,0,0);
    thumbnailRect.origin=CGPointMake(0.0,0.0);
    thumbnailRect.size.width=targetSize.width;
    thumbnailRect.size.height=targetSize.height;
    [image drawInRect:thumbnailRect];
    tempImage=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSData*imatgeEnviada=UIImageJPEGRepresentation(tempImage,1.0);
    UIImage*image2=[[UIImage alloc] initWithData:imatgeEnviada];
    NSLog(@"%@%f%@%f",@"Nou Tamany imatge: ",image2.size.height,@" ",image2.size.width);
    self.imageData= UIImageJPEGRepresentation(image2,1.0);
    NSString *strUrl =[NSString stringWithFormat:@"%@",@"http://ges-work.com/pujarApuntS.php"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:strUrl]];
    request.HTTPMethod = @"POST";
    [request setValue:@"mamieli" forHTTPHeaderField:@"User-Agent"];
    [request setValue:@"close" forHTTPHeaderField:@"Connection"];
    request.timeoutInterval = 120;
    request.HTTPShouldHandleCookies = false;
    NSString *boundary = @"----------SwIfTeRhTtPrEqUeStBoUnDaRy";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"mamieli" forHTTPHeaderField:@"User-Agent"];
    [request setValue:@"close" forHTTPHeaderField:@"Connection"];
    NSMutableData *body = [NSMutableData data];
    NSMutableData *tempData = [NSMutableData data];
    [tempData appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    NSString*nomFitxer=@"imatge.jpeg";
    [tempData appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"userfile\"; filename=\"%@\"\r\n",nomFitxer] dataUsingEncoding:NSUTF8StringEncoding]];
    [tempData appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [tempData appendData:[NSData dataWithData:self.imageData]];
    [tempData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData: tempData];
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setValue: [NSString stringWithFormat:@"%lu", (unsigned long)body.length ] forHTTPHeaderField:@"Content-Length"];
    request.HTTPBody =body;
    NSOperationQueue*cua10 = [[NSOperationQueue alloc]init];
    [NSURLConnection sendAsynchronousRequest:request queue:cua10 completionHandler:^(NSURLResponse *response1, NSData *data, NSError *error1) {
        if (data) {
            dispatch_async (dispatch_get_main_queue (),^{
                esticEnviant=NO;
                
                NSLog(@"Tenim Data");
                NSString*resposta=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding ];
                if ([resposta isEqualToString: @"guardat"]) {
                    NSLog(@"Guardat");
                    [self.Pagines removeObjectAtIndex:0];
                }else{
                    NSLog(@"Error guardant");
                    //[self noGuardat];
                }
            });
        }else{
            dispatch_async (dispatch_get_main_queue (),^{
                NSLog(@"No Tenim Data");
                //[self errorEnviant];
            });
        }
    }];
   }
-(void)enviarServidor{
    NSString*usuari=@"etoimosapp@gmail.com";
    NSLog(@"Ja temim la foto.., que faig?");
    UIImage*image=[[UIImage alloc] initWithData:self.imatgeData];
    
    NSLog(@"%@%f%@%f",@"Tamany imatge: ",image.size.height,@" ",image.size.width);
    
    float w=image.size.width;
    float h=image.size.height;
    
    UIImage*tempImage=nil;
    CGSize targetSize=CGSizeMake(w/4,h/4);
    UIGraphicsBeginImageContext(targetSize);
    CGRect thumbnailRect=CGRectMake(0,0,0,0);
    thumbnailRect.origin=CGPointMake(0.0,0.0);
    thumbnailRect.size.width=targetSize.width;
    thumbnailRect.size.height=targetSize.height;
    [image drawInRect:thumbnailRect];
    tempImage=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSData*imatgeEnviada=UIImageJPEGRepresentation(tempImage,1.0);
    
    UIImage*image2=[[UIImage alloc] initWithData:imatgeEnviada];
    
    //NSData*imageData=UIImagePNGRepresentation(video1.imatge1);
    //NSData*imageData= UIImageJPEGRepresentation(imatge,1.0);
    
    NSString*imatgeEnviada1=[imatgeEnviada base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    NSLog(@"%@%lu",@"Tamany String: ",(unsigned long)imatgeEnviada1.length);
     NSLog(@"%@%f%@%f",@"Tamany imatge: ",image2.size.height,@" ",image2.size.width);
    NSLog(@"imatge comprimida");
    
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  usuari,@"user",
                                  imatgeEnviada1,@"escan",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/tt.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
    }];
}

-(void)enviarServidor2{
    UIImage*image=[[UIImage alloc] initWithData:self.imatgeData];
    NSLog(@"%@%f%@%f",@"Tamany imatge Original: ",image.size.height,@" ",image.size.width);
    float w=image.size.width;
    float h=image.size.height;
    int x = 2;
    if (w>100000) {
        x=6;
    }else{
        if (w>10000 && w<=100000) {
            x=3;
        }else{
            
            
        }
    }
    
    UIImage*tempImage=nil;
    CGSize targetSize=CGSizeMake(w/x,h/x);
    UIGraphicsBeginImageContext(targetSize);
    CGRect thumbnailRect=CGRectMake(0,0,0,0);
    thumbnailRect.origin=CGPointMake(0.0,0.0);
    thumbnailRect.size.width=targetSize.width;
    thumbnailRect.size.height=targetSize.height;
    [image drawInRect:thumbnailRect];
    tempImage=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSData*imatgeEnviada=UIImageJPEGRepresentation(tempImage,1.0);
    UIImage*image2=[[UIImage alloc] initWithData:imatgeEnviada];
    NSLog(@"%@%f%@%f",@"Nou Tamany imatge: ",image2.size.height,@" ",image2.size.width);
    self.imageData= UIImageJPEGRepresentation(image2,1.0);
    NSString *strUrl =[NSString stringWithFormat:@"%@",@"http://ges-work.com/tt2.php"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:strUrl]];
    request.HTTPMethod = @"POST";
    [request setValue:@"mamieli" forHTTPHeaderField:@"User-Agent"];
    [request setValue:@"close" forHTTPHeaderField:@"Connection"];
    request.timeoutInterval = 120;
    request.HTTPShouldHandleCookies = false;
    NSString *boundary = @"----------SwIfTeRhTtPrEqUeStBoUnDaRy";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"mamieli" forHTTPHeaderField:@"User-Agent"];
    [request setValue:@"close" forHTTPHeaderField:@"Connection"];
    NSMutableData *body = [NSMutableData data];
    NSMutableData *tempData = [NSMutableData data];
    [tempData appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    [defaults3vc objectForKey:@"usuari"];
    NSDate*today=[NSDate date];
    NSDateFormatter*formatter=[[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyyMMddHHmmss"];
    NSString*imatgeProvisional=[formatter stringFromDate:today];
    [defaults3vc setObject:imatgeProvisional forKey:@"enviant"];
    [defaults3vc synchronize];
    NSString*nomDefinitiu=[NSString stringWithFormat:@"%@%@%@%@", [defaults3vc objectForKey:@"usuari"], @"/", imatgeProvisional, @".jpeg"];
    NSLog(@"%@", nomDefinitiu);
    [tempData appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"userfile\"; filename=\"%@\"\r\n",nomDefinitiu] dataUsingEncoding:NSUTF8StringEncoding]];
    [tempData appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [tempData appendData:[NSData dataWithData:self.imageData]];
    [tempData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData: tempData];
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setValue: [NSString stringWithFormat:@"%lu", (unsigned long)body.length ] forHTTPHeaderField:@"Content-Length"];
    request.HTTPBody =body;
    NSOperationQueue*cua10 = [[NSOperationQueue alloc]init];
    [NSURLConnection sendAsynchronousRequest:request queue:cua10 completionHandler:^(NSURLResponse *response1, NSData *data, NSError *error1) {
        if (data) {
            dispatch_async (dispatch_get_main_queue (),^{
                NSLog(@"Tenim Data");
            NSString*resposta=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding ];
            if ([resposta isEqualToString: @"guardat"]) {
                NSLog(@"Guardat");
                //[self guardat];
            }else{
                NSLog(@"Error guardant");
                [self noGuardat];
            }
            });
        }else{
            dispatch_async (dispatch_get_main_queue (),^{
                NSLog(@"No Tenim Data");
                [self errorEnviant];
            });
        }
    }];
}

-(void)guardat{
    //UIAlertView *imatgeGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Pujat",) message:NSLocalizedString(@"Apunts enviats correctament",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
    //[imatgeGuardada show];
    //Guardem a BDD
    NSDate*avui=[NSDate date];
    NSString*carpeta2=self.dadesApunt[0];
    NSString*tema2=self.nomTema;
    NSString*nom2=self.nomAssignatura;
    Apunt*mis2=[NSEntityDescription insertNewObjectForEntityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext222];
    [mis2 setDataCreacio:avui];
    [mis2 setAssignatura:carpeta2];
    [mis2 setTema:tema2];
    [mis2 setNom:nom2];
    [mis2 setImatge:self.imageData];
    NSError*error;
    if (![self.managedObjectContext222 save:&error]){
        NSLog(@"No s'ha guardat a la BDD");
    }else{
        NSLog(@"Apunt guardat a la BDD");
    }
}

-(void)quinaAssignatura{
    NSMutableArray*arrayAssignatures=[[NSMutableArray alloc] init];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    //[defaults3vc setObject:nil forKey:@"Assignatures"];
    //[defaults3vc synchronize];
    if ([defaults3vc objectForKey:@"Assignatures"] ==nil) {
        NSArray*assignatura1=[[NSArray alloc]initWithObjects:@"Filosofia", @"Presentació inicial", nil];
        NSArray*assignatura2=[[NSArray alloc]initWithObjects:@"Català", @"Presentació inicial", nil];
        NSArray*assignatura3=[[NSArray alloc]initWithObjects:@"Castellà", @"Presentació inicial", nil];
        [arrayAssignatures addObject:assignatura1];
        [arrayAssignatures addObject:assignatura2];
        [arrayAssignatures addObject:assignatura3];
        [defaults3vc setObject:arrayAssignatures forKey:@"Assignatures"];
        [defaults3vc synchronize];
    }else{
        arrayAssignatures = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Assignatures"]];
    }
    self.ordre = @"2";
    UIAlertView *imatgeNoGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Selecciona assignatura",) message:NSLocalizedString(@"On ho vols guardar?",) delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel·lar",) otherButtonTitles:nil];
    
    for(NSArray *buttonTitle in arrayAssignatures) {
        [imatgeNoGuardada addButtonWithTitle:buttonTitle[0]];
       

    }
    [imatgeNoGuardada show];
}


-(void)quinTema:(NSString*)assignatura{
    NSMutableArray*arrayAssignatures=[[NSMutableArray alloc] init];
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    //[defaults3vc setObject:nil forKey:@"Assignatures"];
    //[defaults3vc synchronize];
    if ([defaults3vc objectForKey:@"Assignatures"] ==nil) {
        NSArray*assignatura1=[[NSArray alloc]initWithObjects:@"Filosofia", @"Presentació inicial", nil];
        NSArray*assignatura2=[[NSArray alloc]initWithObjects:@"Català", @"Presentació inicial", nil];
        NSArray*assignatura3=[[NSArray alloc]initWithObjects:@"Castellà", @"Presentació inicial", nil];
        [arrayAssignatures addObject:assignatura1];
        [arrayAssignatures addObject:assignatura2];
        [arrayAssignatures addObject:assignatura3];
        [defaults3vc setObject:arrayAssignatures forKey:@"Assignatures"];
        [defaults3vc synchronize];
    }else{
        arrayAssignatures = [NSMutableArray arrayWithArray:[defaults3vc objectForKey:@"Assignatures"]];
    }
    for(NSArray *temes in arrayAssignatures) {
        if ([temes[0] isEqualToString:assignatura]){
            self.dadesApunt=[[NSArray alloc]initWithArray:temes];
            self.ordre = @"3";
            UIAlertView *imatgeNoGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Selecciona tema",) message:NSLocalizedString(@"On ho vols guardar?",) delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel·lar",) otherButtonTitles:nil];
            for(int j = 1; j < [temes count]; j++) {
                [imatgeNoGuardada addButtonWithTitle:temes[j]];
            }
            [imatgeNoGuardada show];
        }
    }
}

-(void)quinNom{
    self.nomAssignatura=@"";
    self.telInfo=[[UITextField alloc]initWithFrame:CGRectMake(10,10,280,44)];
    self.telInfo.text=@"";
    //self.nouValor=@" ";
    self.telInfo.keyboardType=UIKeyboardTypeNumberPad;
    //self.nouValor=@"nom";
    self.telInfo.placeholder=NSLocalizedString(@"Nom apunt",);
    self.telInfo.keyboardType=UIKeyboardTypeDefault;
    self.telInfo.delegate=self;
    self.telInfo.backgroundColor=[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1];
    self.telInfo.layer.cornerRadius=8;
    self.telInfo.layer.masksToBounds=YES;
    self.telInfo.textAlignment=NSTextAlignmentCenter;
    //self.telInfo.textColor=[UIColor colorWithRed:rojoLletra/255.0 green:verdeLletra/255.0 blue:azulLletra/255.0 alpha:1];
    //self.telInfo.font=[UIFont fontWithName:@"AppleSDGothicNeo-Bold" size:20];
    CGFloat tamanyPantalla=[[UIScreen mainScreen] bounds].size.height;
    CGFloat tamanyPantalla2=[[UIScreen mainScreen] bounds].size.width;
    NSLog(@"%f",tamanyPantalla);
    NSLog(@"%f",tamanyPantalla2);
    self.infoInteres=[[UIView alloc]initWithFrame:CGRectMake((tamanyPantalla2-300)/2,tamanyPantalla-450,300,120)];
    self.infoInteres.backgroundColor=[UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1];
    self.infoInteres.layer.cornerRadius=15;
    self.infoInteres.layer.masksToBounds=YES;
    UIButton*accioCancelar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioCancelar setTitle:NSLocalizedString(@"Cancelar",) forState:UIControlStateNormal];
    [accioCancelar addTarget:self action:@selector(cancelar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioCancelar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioCancelar setFrame:CGRectMake(10,70,120,24)];
    UIButton*accioGuardar=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    [accioGuardar setTitle:NSLocalizedString(@"Guardar",) forState:UIControlStateNormal];
    [accioGuardar addTarget:self action:@selector(guardar:) forControlEvents:UIControlEventTouchUpInside];
    [[accioGuardar titleLabel] setFont:[UIFont fontWithName:@"Helvetica" size:20]];
    [accioGuardar setFrame:CGRectMake(170,70,120,24)];
    [self.infoInteres addSubview:accioGuardar];
    [self.infoInteres addSubview:accioCancelar];
    [self.infoInteres addSubview:self.telInfo];
    [[self view] addSubview:self.infoInteres];
}

-(void)guardar:(NSString*)valorGuardar{
    if ([self.telInfo.text length]>0){
        self.nomAssignatura=self.telInfo.text;
        [self.infoInteres removeFromSuperview];
        NSLog(@"%@%@",@"Nom document: ",self.nomAssignatura);
        [self contactarServidor];
        
    }
}

-(void)contactarServidor{
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    NSString*assignatura=self.dadesApunt[0];
    NSString*tema=self.nomTema;
    NSString*titol=self.nomAssignatura;
    NSString*referencia=[defaults3vc objectForKey:@"enviant"];
    NSString*usuari=[defaults3vc objectForKey:@"usuari"];
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  assignatura,@"assignatura",
                                  tema,@"tema",
                                  titol,@"titol",
                                  referencia,@"referencia",
                                  usuari,@"usuari",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/apunts.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if (!error) {
            [self guardat];
        }
    }];
}


-(BOOL)textFieldShouldReturn:(UITextField*)textField{
    [self.telInfo resignFirstResponder];
    return YES;
}

-(void)cancelar:(NSString*)valorGuardar{
    self.nomAssignatura=@"";
    [self.infoInteres removeFromSuperview];
}

-(void)noGuardat{
    UIAlertView *imatgeNoGuardada = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"No guardat",) message:NSLocalizedString(@"No hem pogut guardar apunts",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
    [imatgeNoGuardada show];
}

-(void)errorEnviant{
    UIAlertView *errorImatge = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Error",) message:NSLocalizedString(@"Hi ha hagut un problema",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
    [errorImatge show];
    
}

- (void)dismissPreview:(UITapGestureRecognizer *)dismissTap
{
    [UIView animateWithDuration:0.7 delay:0.0 usingSpringWithDamping:0.8 initialSpringVelocity:1.0 options:UIViewAnimationOptionAllowUserInteraction animations:^
    {
        dismissTap.view.frame = CGRectOffset(self.view.bounds, 0, self.view.bounds.size.height);
    }
    completion:^(BOOL finished)
    {
        [dismissTap.view removeFromSuperview];
    }];
}

@end
