//
//  Apunts.h
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 28/6/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Apunt+CoreDataClass.h"

@interface Apunts : UIViewController <UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITableView *taulaApunts;
@property (nonatomic,retain) NSMutableArray*arrayAssignatures;
@property (retain,nonatomic) UIView*infoInteres;
@property (retain,nonatomic) UITextField*telInfo;
@property (retain,nonatomic) NSString*nomAssignatura;
@property int n;

@property (readonly,strong,nonatomic) NSManagedObjectContext*managedObjectContext221;
@property (readonly,strong,nonatomic) NSManagedObjectModel*managedObjectModel221;
@property (readonly,strong,nonatomic) NSPersistentStoreCoordinator*persistentStoreCoordinator221;

- (IBAction)crearAssignatura:(id)sender;

@end
