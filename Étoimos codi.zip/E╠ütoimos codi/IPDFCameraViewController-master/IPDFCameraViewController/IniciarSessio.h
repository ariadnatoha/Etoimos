//
//  IniciarSessio.h
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 2/7/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IniciarSessio : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *Usuari;
@property (weak, nonatomic) IBOutlet UITextField *Clau;

@property (nonatomic, retain) NSString *Usuari2;
@property (nonatomic, retain) NSString *Clau2;
@property (nonatomic, retain) NSString *Resposta;

- (IBAction)Comença:(id)sender;

@end
