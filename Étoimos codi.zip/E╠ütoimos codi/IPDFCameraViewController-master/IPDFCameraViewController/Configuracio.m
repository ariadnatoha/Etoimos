//
//  Configuracio.m
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 25/7/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import "Configuracio.h"

@interface Configuracio ()

@end

@implementation Configuracio
@synthesize taulaConfiguracio, arrayConfiguracio;


- (void)viewDidLoad {
    [super viewDidLoad];
    self.arrayConfiguracio=[[NSMutableArray alloc] init];
    [self.arrayConfiguracio addObject:@"Nom d'usuari:"];
    [self.arrayConfiguracio addObject:@"Tancar sessió"];
    [self.arrayConfiguracio addObject:@"Eliminar compte"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayConfiguracio.count;
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString*CellIdentifier=@"Cell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell){
        /*/
        if (indexPath.row == 0){
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            cell.detailTextLabel.text=@"hola";
        }else{
         */
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        //}
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    if (indexPath.row == 0){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
                NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
        if (([defaults3vc objectForKey:@"usuari"]==nil) || ([[defaults3vc objectForKey:@"usuari"] isEqualToString:@""])) {
            cell.detailTextLabel.text=@"Sense usuari";
        }else{
            cell.detailTextLabel.text=[defaults3vc objectForKey:@"usuari"];
        }
    }
    cell.textLabel.text=[self.arrayConfiguracio objectAtIndex:indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.row == 0){
        return 60;
    } else{
        return 40;
    }
}


-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.row == 0) {
        NSLog(@"Cel.la 0");
        UITableViewCell*cell=[self.taulaConfiguracio cellForRowAtIndexPath:indexPath];
        cell.selected=NO;
        //[self.arrayAssignatures addObject:@"Hola"];
        //NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
        //[defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
        //[defaults3vc synchronize];
        //[self.taulaApunts reloadData];
    }else{
        if (indexPath.row == 1) {
            NSLog(@"Cel.la 1");
            NSUserDefaults*usu=[NSUserDefaults standardUserDefaults];
            [usu setObject:nil forKey:@"usuari"];
            [usu synchronize];
            [self dismissViewControllerAnimated:YES completion:nil];            
        /*
         [self.arrayAssignatures removeObjectAtIndex:indexPath.row];
         NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
         [defaults3vc setObject:self.arrayAssignatures forKey:@"Assignatures"];
         [defaults3vc synchronize];
         [self.taulaApunts reloadData];
         */
        }else{
            if (indexPath.row == 2) {
                UITableViewCell*cell=[self.taulaConfiguracio cellForRowAtIndexPath:indexPath];
                cell.selected=NO;
                NSLog(@"Cel.la 2");
                UIAlertView *eliminarUser = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Eliminar usuari",) message:NSLocalizedString(@"Si elimines l'usuari es borraran tots els teus apunts i les teves dades",) delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel·lar",) otherButtonTitles:NSLocalizedString(@"Continuar",),nil];
                [eliminarUser show];
            }
        }
    
    }
}
- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==1){
        NSLog(@"Clicat CONTINUAR");
        [self eliminarUsuari];
        
    }
}
- (void)eliminarUsuari {
    NSLog(@"Anem a contactar amb Servidor");
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    NSString*user=[defaults3vc objectForKey:@"usuari"];
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  user,@"usuari",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/baixa.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if (data && !error1) {
            if ([newStr isEqualToString:@"ok"]) {
                [self baixaCorrecta];
            }
            if ([newStr isEqualToString:@"no"]) {
                [self baixaIncorrecta];
                
            }
        }
        
        
    }];
}
-(void)baixaCorrecta {
    //També s'han d'eliminar els delegats i contingut de la base de dades?
    NSLog(@"Funciona?");
    dispatch_async (dispatch_get_main_queue (),^{
        NSUserDefaults*usu=[NSUserDefaults standardUserDefaults];
        [usu setObject:nil forKey:@"Assignatures"];
        [usu setObject:nil forKey:@"usuari"];
        [usu synchronize];
        [self dismissViewControllerAnimated:YES completion:nil];
    });
}
-(void)baixaIncorrecta {
    UIAlertView *noEliminat = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"No s'ha pogut eliminar",) message:NSLocalizedString(@"Pot ser degut a un problema de cobertura, intenta-ho més tard",) delegate:nil cancelButtonTitle:NSLocalizedString(@"OK",) otherButtonTitles:nil];
    [noEliminat show];
}

- (IBAction)enrere:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
