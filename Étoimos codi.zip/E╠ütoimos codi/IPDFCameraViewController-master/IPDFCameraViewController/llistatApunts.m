//
//  llistatApunts.m
//  Étoimos
//
//  Created by Ariadna Toha on 2/9/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import "llistatApunts.h"
#import "AppDelegate.h"
#import <CoreData/CoreData.h>
#import "veureFoto.h"

@interface llistatApunts ()

@end

@implementation llistatApunts
@synthesize navigationBar,navigationItem,dadesRebudes,assignaturaRebuda,temaRebut,arrayApunts,objecteEliminar,imatgeMostrar2,nomApuntSeleccionat;
@synthesize managedObjectContext224=_managedObjectContext224;
@synthesize managedObjectModel224=_managedObjectModel224;
@synthesize persistentStoreCoordinator224=_persistentStoreCoordinator224;

- (void)viewDidLoad {
    [super viewDidLoad];
    AppDelegate*appDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    _managedObjectContext224=[appDelegate managedObjectContext];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.assignaturaRebuda=[self.dadesRebudes objectAtIndex:0];
    self.temaRebut=[self.dadesRebudes objectAtIndex:1];
    self.navigationItem.title=self.temaRebut;
    NSLog(@"%@%@",@"Assignatura Rebuda: ",self.assignaturaRebuda);
    NSLog(@"%@%@",@"Tema Rebut Rebut: ",self.temaRebut);
    [self inicialitzar];
}
    
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)inicialitzar{
    self.arrayApunts=[[NSMutableArray alloc] init];
    NSFetchRequest*request2=[[NSFetchRequest alloc]init];
    NSEntityDescription*lloc2=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext224];
    [request2 setEntity:lloc2];
    NSSortDescriptor*sortDescriptor=[NSSortDescriptor sortDescriptorWithKey:@"dataCreacio" ascending:NO];
    NSArray*sortDescriptors=[[NSArray alloc]initWithObjects:sortDescriptor, nil];
    [request2 setSortDescriptors:sortDescriptors];
    NSPredicate*predicate12=[NSPredicate predicateWithFormat:@"(assignatura == %@) && (tema == %@)",self.assignaturaRebuda,self.temaRebut];
    [request2 setPredicate:predicate12];
    NSError*error;
    NSArray*mutableFetchRequest=[self.managedObjectContext224 executeFetchRequest:request2 error:&error];
    if (mutableFetchRequest==nil){
        NSLog(@"No hi ha cap apunt");
    }else{
        NSLog(@"%@%lu",@"Tenim apunts: ",(unsigned long)mutableFetchRequest.count);
        for (NSManagedObject*apunt9 in mutableFetchRequest){
            NSDate*dataApunt=[apunt9 valueForKey:@"dataCreacio"];
            NSString*nomApunt=[apunt9 valueForKey:@"nom"];
            NSDateFormatter*anyMesDia=[[NSDateFormatter alloc] init];
            //NSDateFormatter*horaMinut=[[NSDateFormatter alloc] init];
            [anyMesDia setDateFormat:@"E, dd MMM yyyy H:mm"];
            //[horaMinut setDateFormat:@"H:mm"];
            NSString*data1=[anyMesDia stringFromDate:dataApunt];
            //NSString*data2=[horaMinut stringFromDate:dataApunt];
            NSLog(@"%@%@",@"Nom apunt: ",nomApunt);
            NSLog(@"%@%@",@"Data apunt: ",data1);
            NSArray*objecteApunt=[[NSArray alloc] initWithObjects:nomApunt,dataApunt,nil];
            [self.arrayApunts addObject:objecteApunt];
        }
        [self.taulaDetall reloadData];
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView*)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayApunts.count;
}

-(NSString*)tableView:(UITableView*)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0 && self.arrayApunts.count>0){
        return NSLocalizedString(@"Eliminar",);
    }else{
        return nil;
    }
}

-(UITableViewCellEditingStyle)tableView:(UITableView*)tableView editingStyleForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (self.arrayApunts.count>0 && indexPath.section==0){
        return UITableViewCellEditingStyleDelete;
    }else{
        return UITableViewCellEditingStyleNone;
    }
}

-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0 && self.arrayApunts.count>0){
        return 80;
    }else{
        return 20;
    }
}

-(void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath*)indexPath{
    if (indexPath.section==0 && self.arrayApunts.count>0){
        if (editingStyle==UITableViewCellEditingStyleDelete){
            self.objecteEliminar=[[NSArray alloc]initWithArray:[self.arrayApunts objectAtIndex:indexPath.row]];
            [self.taulaDetall reloadData];
            [self alertaBorrar];
        }else{
            if (editingStyle==UITableViewCellEditingStyleNone){
                
            }
        }
    }
}

-(void)alertaBorrar{
    UIAlertView *eliminarApunt = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Eliminar apunt",) message:NSLocalizedString(@"Si continues eliminarás aquest apunt i ja no el podràs recuperar",) delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel·lar",) otherButtonTitles:NSLocalizedString(@"Continuar",),nil];
    [eliminarApunt show];
}

-(void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==1){
        NSLog(@"Clicat Continuar");
        [self enviarServidor2];
    }
}

-(void)enviarServidor2{
    NSUserDefaults*defaults3vc=[NSUserDefaults standardUserDefaults];
    NSString*usuari=[defaults3vc objectForKey:@"usuari"];
    NSDictionary*requestContents=[NSDictionary dictionaryWithObjectsAndKeys:
                                  self.assignaturaRebuda,@"assignatura",
                                  usuari,@"usuari",
                                  self.temaRebut,@"tema",
                                  [objecteEliminar objectAtIndex:0],@"nomApunt",
                                  nil];
    NSError*error;
    NSData*requestData=[NSJSONSerialization dataWithJSONObject:requestContents
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSMutableURLRequest*postRequest=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ges-work.com/baixaApunt.php"]];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [postRequest setValue:@"close" forHTTPHeaderField:@"Connection"];
    [postRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[requestData length]] forHTTPHeaderField:@"Content-Length"];
    [postRequest setHTTPBody:requestData];
    [NSURLConnection sendAsynchronousRequest:postRequest queue:[[NSOperationQueue alloc]init] completionHandler:^(NSURLResponse*response1,NSData*data,NSError*error1){
        
        NSString*newStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",newStr);
        if ([newStr isEqualToString:@"ok"]){
            dispatch_async (dispatch_get_main_queue (),^{
                [self confirmatBorrar];
            });
        }
    }];
}

-(void)confirmatBorrar{
    NSLog(@"Eliminat");
    NSFetchRequest*request12=[[NSFetchRequest alloc]init];
    NSEntityDescription*amics12=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext224];
    [request12 setEntity:amics12];
    NSPredicate* predicate12=[NSPredicate predicateWithFormat:@"(assignatura == %@ && tema == %@ && dataCreacio == %@ && nom == %@)", self.assignaturaRebuda, self.temaRebut, [objecteEliminar objectAtIndex:1], [objecteEliminar objectAtIndex:0]];
    [request12 setPredicate:predicate12];
    NSError*error22;
    NSArray*matchingData12=[self.managedObjectContext224 executeFetchRequest:request12 error:&error22];
    NSLog(@"%@%lu", @"Hem borrat apunts: ", (unsigned long)matchingData12.count);
    if (matchingData12.count>0){
        for (int i=0;i<matchingData12.count;i++){
            NSManagedObject*missatgeBorrar=[matchingData12 objectAtIndex:i];
            [self.managedObjectContext224 deleteObject:missatgeBorrar];
            NSError*error33;
            if (![self.managedObjectContext224 save:&error33]){
                
                
            }
        }
        [self inicialitzar];
    }
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath{
    static NSString*CellIdentifier=@"Cell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        //cell.accessoryType=UITableViewCellAccessoryNone;
    }
    NSArray*objecteVisualizar=[[NSArray alloc] initWithArray:[self.arrayApunts objectAtIndex:indexPath.row]];
    cell.textLabel.text=[objecteVisualizar objectAtIndex:0];
    
    NSDateFormatter*anyMesDia=[[NSDateFormatter alloc] init];
    //NSDateFormatter*horaMinut=[[NSDateFormatter alloc] init];
    [anyMesDia setDateFormat:@"E, dd MMM yyyy H:mm"];
    //[horaMinut setDateFormat:@"H:mm"];
    cell.detailTextLabel.text=[anyMesDia stringFromDate:[objecteVisualizar objectAtIndex:1]];
    //cell.detailTextLabel.text=[objecteVisualizar objectAtIndex:1];
    return cell;
}

-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{
    UITableViewCell*cell=[self.taulaDetall cellForRowAtIndexPath:indexPath];
    cell.selected=NO;
    //self.anarTema=[[NSArray alloc]initWithObjects:[self.arrayTemes objectAtIndex:0],[self.arrayTemes objectAtIndex:(indexPath.row + 1)] ,nil];
    //self.anarTema=[self.arrayTemes objectAtIndex:(indexPath.row + 1)];
    NSArray*cercoNom=[[NSArray alloc]initWithArray:[self.arrayApunts objectAtIndex:indexPath.row]];
    self.nomApuntSeleccionat=[cercoNom objectAtIndex:0];
    [self anarFoto];
}

-(void)anarFoto{
    NSLog(@"%@%@",@"Nom apunt seleccionat per veure: ",self.nomApuntSeleccionat);
    NSFetchRequest*request3=[[NSFetchRequest alloc]init];
    NSEntityDescription*lloc2=[NSEntityDescription entityForName:@"Apunt" inManagedObjectContext:self.managedObjectContext224];
    [request3 setEntity:lloc2];
    NSPredicate*predicate12=[NSPredicate predicateWithFormat:@"(assignatura == %@) && (tema == %@) && (nom == %@)",self.assignaturaRebuda,self.temaRebut,self.nomApuntSeleccionat];
    [request3 setPredicate:predicate12];
    NSError*error2;
    NSArray*mutableFetchRequest2=[self.managedObjectContext224 executeFetchRequest:request3 error:&error2];
    if (mutableFetchRequest2==nil){
        NSLog(@"No hi ha cap apunt");
    }else{
        NSLog(@"%@%lu",@"Tenim apunts: ",(unsigned long)mutableFetchRequest2.count);
        for (NSManagedObject*apunt9 in mutableFetchRequest2){
            self.imatgeMostrar2=[UIImage imageWithData:[apunt9 valueForKey:@"imatge"]];
        }
    }
    [self performSegueWithIdentifier:@"veureFoto" sender:self];
}

- (IBAction)tornar:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"veureFoto"]){
        //[segue destinationViewController];
        [[segue destinationViewController] setImatgeRebuda:imatgeMostrar2];
    }
}

@end
