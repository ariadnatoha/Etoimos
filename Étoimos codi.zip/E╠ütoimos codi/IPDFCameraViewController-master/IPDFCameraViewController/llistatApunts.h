//
//  llistatApunts.h
//  Étoimos
//
//  Created by Ariadna Toha on 2/9/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Apunt+CoreDataClass.h"

@interface llistatApunts : UIViewController <UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UINavigationItem*navigationItem;
@property (weak, nonatomic) IBOutlet UINavigationBar*navigationBar;
@property (weak, nonatomic) IBOutlet UITableView*taulaDetall;
@property (retain,nonatomic) NSArray*dadesRebudes;
@property (retain,nonatomic) NSString*assignaturaRebuda;
@property (retain,nonatomic) NSString*temaRebut;
@property (nonatomic, nonatomic) NSMutableArray*arrayApunts;
@property (retain,nonatomic) NSArray*objecteEliminar;
@property (nonatomic,retain) UIImage*imatgeMostrar2;
@property (retain,nonatomic) NSString*nomApuntSeleccionat;

@property (readonly,strong,nonatomic) NSManagedObjectContext*managedObjectContext224;
@property (readonly,strong,nonatomic) NSManagedObjectModel*managedObjectModel224;
@property (readonly,strong,nonatomic) NSPersistentStoreCoordinator*persistentStoreCoordinator224;

-(IBAction)tornar:(id)sender;

@end
