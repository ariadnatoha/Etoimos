//
//  registre.h
//  IPDFCameraViewControllerDemo
//
//  Created by Ariadna Toha on 16/6/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface registre : UIViewController <UITextFieldDelegate>


@property (weak, nonatomic) IBOutlet UITextField *etiquetaNom;
@property (weak, nonatomic) IBOutlet UITextField *etiquetaCorreu;
@property (weak, nonatomic) IBOutlet UITextField *etiquetaClau;
@property (weak, nonatomic) IBOutlet UITextField *comprovacioClau;

- (IBAction)accioOk:(id)sender;
- (IBAction)accioEnrere:(id)sender;

@property (nonatomic, retain) NSString *nomUsuari;




@end
