//
//  Temes.h
//  ÉtoimosApp
//
//  Created by Ariadna Toha on 27/7/17.
//  Copyright © 2017 Ariadna Toha. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Apunt+CoreDataClass.h"

@interface Temes : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UINavigationBar *navigationBar;
@property (weak, nonatomic) IBOutlet UINavigationItem *navigationItem;
@property int a;
@property (nonatomic, nonatomic) NSMutableArray*arrayAssignatures;
@property (nonatomic, nonatomic) NSMutableArray*arrayTemes;
@property (weak, nonatomic) IBOutlet UITableView *taulaTemes;

@property (retain,nonatomic) UIView*infoInteres;
@property (retain,nonatomic) UITextField*telInfo;
@property (retain,nonatomic) NSString*nomAssignatura;
@property (retain,nonatomic) NSString*assignaturaEliminar;
@property (retain,nonatomic) NSString*temaEliminar;
@property (retain,nonatomic) NSArray*anarTema;
@property (retain,nonatomic) NSIndexPath*indexSeleccionat;

@property (readonly,strong,nonatomic) NSManagedObjectContext*managedObjectContext221;
@property (readonly,strong,nonatomic) NSManagedObjectModel*managedObjectModel221;
@property (readonly,strong,nonatomic) NSPersistentStoreCoordinator*persistentStoreCoordinator221;

- (IBAction)enrere:(id)sender;
- (IBAction)temaNou:(id)sender;

@end
