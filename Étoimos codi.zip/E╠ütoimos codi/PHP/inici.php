<?php
	$gestor = fopen("php://input", "rb");
   	$contenido = stream_get_contents($gestor);
   	$request = json_decode($contenido, true);
   	fclose($gestor);
   	$user = $request['usuari'];
   	$pass = $request['contrassenya'];
   	//$user = "wwww";
   	//$pass = "eeeeee";
   	$dir = "/var/www/vhost/ges-work.com/home/data/etoimos/".$user;
   	$resposta = "1";
   	if (is_dir($dir)) {
    	//Ja existeix   
    	//echo "no";
    	$resposta = "2";   
	}else { 
		$resposta = "3";
	}
	$host = "qyc278.ges-work.com";
	//$host = "localhost";
	$db = "qyc278";
	$user2 = "qyc279";
	$pass2 = "Etoimosapp3";
	$connection = mysqli_connect($host,$user2,$pass2);
	if(!$connection){
       die ('Conexio fallat: ' . mysqli_connect_error());
   	}
	$dbconnect = mysqli_select_db($connection,$db);
	if(!$dbconnect){
        die ('No BDD: ' . mysqli_error($connection));
    }
	
    $query = "SELECT * FROM Usuarios WHERE Usuari = '$user' AND Clau= '$pass' LIMIT 1";
   	$results = mysqli_query($connection,$query) or die(mysqli_error($connection));
   	$numResults = mysqli_num_rows($results);
	if ($numResults > 0) {
		//echo "existeix";
		$resposta = $resposta."4";
	} else {
    	$resposta = $resposta."5";
	}
	
	if ($resposta == 24){
		$usuari = $user;
		$directori = "/var/www/vhost/ges-work.com/home/data/etoimos/".$usuari."/";
   		$contents = scandir($directori);
      	if (count($contents) > 0) { 
      		$arrayAssignatures = array(); 
       		for ($i = 0; $i < count($contents); $i++){ 
		 		$assignatures = substr($contents[$i],0);
		 		$arrayNoDirs = array(".","..","...");
				if (in_array($assignatures, $arrayNoDirs)){
		 			//echo "Directori Assignatura: ".$assignatures." el discriminem<br>"; 
		 		}else{
		 			//echo $assignatures."<br>";
		 			$arrayTemes = array();
		 			if (is_dir($directori."/".$assignatures."/")) {
		 				//$arrayTemes[0]=$assignatures;
		 				array_push($arrayTemes,$assignatures);
		 				$contents2 = scandir($directori."/".$assignatures."/");
		 				if (count($contents2) > 0) {  
       						for ($j = 0; $j < count($contents2); $j++){ 
		 						$temes = substr($contents2[$j],0);
		 						if (in_array($temes, $arrayNoDirs)){
		 						
		 						}else{
		 							if (is_dir($directori."/".$assignatures."/".$temes."/")) {
		 								array_push($arrayTemes,$temes);
		 							}
		 						}
		 					}
		 				}
		 				array_push($arrayAssignatures,$arrayTemes);
		 			}
		 		}
		 	}
		 	$json4 = array(
    			'instruccio' => $resposta,
    			'carpetes' => $arrayAssignatures
   			);			
    		echo json_encode($json4,JSON_FORCE_OBJECT);
		 }
	}else{
		$json4 = array(
    		'instruccio' => $resposta
   		);			
    	echo json_encode($json4,JSON_FORCE_OBJECT);
	}
	mysqli_close($connection);
?>