<?php
	//echo "Pedro";
	echo $_GET["v"];
?>