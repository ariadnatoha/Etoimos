<?php
	$gestor = fopen("php://input", "rb");
   	$contenido = stream_get_contents($gestor);
   	$request = json_decode($contenido, true);
   	fclose($gestor);
   	$user = $request['usuari'];
   	$pass = $request['contrassenya'];
   	$eMail = $request['mail'];
   	//$user = "wwww";
   	//$pass = "eeeeee";
   	//$eMail = "hhfhhf";
   	$dir = "/var/www/vhost/ges-work.com/home/data/etoimos/".$user;
   	$resposta = "1";
   	if (is_dir($dir)) {
    	//Ja existeix   
    	//echo "no";
    	$resposta = "2";   
	}else { 
		if (!file_exists($dir)) {
			mkdir($dir, 0777, true);
			//echo "ok";
			$resposta = "3";
		}	
	}
	$dir1 = $dir."/Filosofia";
   	//$resposta = "1";
   	if (is_dir($dir1)) {
    	//$resposta = "2";   
	}else { 
		if (!file_exists($dir1)) {
			mkdir($dir1, 0777, true);
			//echo "ok";
			//$resposta = "3";
		}	
	}
	$dir1=$dir1."/Presentació inicial";
	if (is_dir($dir1)) {
    	//$resposta = "2";   
	}else { 
		if (!file_exists($dir1)) {
			mkdir($dir1, 0777, true);
			//echo "ok";
			//$resposta = "3";
		}	
	}
	$dir3 = $dir."/Català";
   	//$resposta = "1";
   	if (is_dir($dir3)) {
    	//$resposta = "2";   
	}else { 
		if (!file_exists($dir3)) {
			mkdir($dir3, 0777, true);
			//echo "ok";
			//$resposta = "3";
		}	
	}
	$dir3=$dir3."/Presentació inicial";
	if (is_dir($dir3)) {
    	//$resposta = "2";   
	}else { 
		if (!file_exists($dir3)) {
			mkdir($dir3, 0777, true);
			//echo "ok";
			//$resposta = "3";
		}	
	}
	$dir2 = $dir."/Castellà";
   	//$resposta = "1";
   	if (is_dir($dir2)) {
    	//$resposta = "2";   
	}else { 
		if (!file_exists($dir2)) {
			mkdir($dir2, 0777, true);
			//echo "ok";
			//$resposta = "3";
		}	
	}
	$dir2=$dir2."/Presentació inicial";
	if (is_dir($dir2)) {
    	//$resposta = "2";   
	}else { 
		if (!file_exists($dir2)) {
			mkdir($dir2, 0777, true);
			//echo "ok";
			//$resposta = "3";
		}	
	}
	$host = "qyc278.ges-work.com";
	//$host = "localhost";
	$db = "qyc278";
	$user2 = "qyc279";
	$pass2 = "Etoimosapp3";
	$connection = mysqli_connect($host,$user2,$pass2);
	if(!$connection){
       die ('Conexio fallat: ' . mysqli_connect_error());
   	}
	$dbconnect = mysqli_select_db($connection,$db);
	if(!$dbconnect){
        die ('No BDD: ' . mysqli_error($connection));
    }
	
    $query = "SELECT * FROM Usuarios WHERE Usuari = '$user' LIMIT 1";
   	$results = mysqli_query($connection,$query) or die(mysqli_error($connection));
   	$numResults = mysqli_num_rows($results);
	if ($numResults > 0) {
		//echo "existeix";
		$resposta = $resposta."4";
	} else {
		$sql = "INSERT INTO Usuarios (Usuari,Clau,Correu) value ('$user','$pass','$eMail')";
    	$retval = mysqli_query($connection,$sql);
    	if (!$retval){
			die ('No hem pogut incorporar dates: ' . mysqli_error($connection));
    	}
    	$resposta = $resposta."5";
	}
	echo $resposta;
	mysqli_close($connection);
?>