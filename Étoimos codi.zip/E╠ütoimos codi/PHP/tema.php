<?php
	$gestor = fopen("php://input", "rb");
   	$contenido = stream_get_contents($gestor);
   	$request = json_decode($contenido, true);
   	fclose($gestor);
   	$assignatura = $request['assignatura'];
   	$tema = $request['tema'];
   	$usuari = $request['usuari'];
   	 	$dir = "/var/www/vhost/ges-work.com/home/data/etoimos/".$usuari."/".$assignatura."/".$tema;
   	//$resposta = "1";
   	if (is_dir($dir)) {
    	//$resposta = "2";   
	}else { 
		if (!file_exists($dir)) {
			mkdir($dir, 0777, true);
			//echo "ok";
			//$resposta = "3";
		}	
	}
   	echo "ok";
?>