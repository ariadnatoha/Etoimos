<?php 
 $uploaddir= './upload/';
 $file = basename($_FILES['userfile']['name']);
 $uploadFile = '.jpeg';
 $newName = $file . $uploadFile;
 $newName2 = "imatgeS.jpeg";
 chdir('/var/www/vhost/ges-work.com/home/data/etoimos/');
 if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
 	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $newName2)){
		echo "guardat";
		flush();
 	} 
 }
 exit();
?>