<?php
   	//$gestor = fopen("php://input", "rb");
   	//$contenido = stream_get_contents($gestor);
   	//$request = json_decode($contenido, true);
   	//fclose($gestor);
   	$tel = "Hola";
   	$carpeta = "/var/www/vhost/ges-work.com/home/data/etoimos/".$tel;
   	echo getcwd() . "\n";
   	if (!file_exists($carpeta)) {
   		echo "No existeix";
    	mkdir($carpeta, 0777, true);
   	}
    usleep(10000);
    $carpeta2 = $carpeta."/enviats";
    if (!file_exists($carpeta2)) {
    	mkdir($carpeta2, 0777, true);
    }
    usleep(10000);
    
    $carpeta2 = $carpeta."/a";
    if (!file_exists($carpeta2)) {
    	mkdir($carpeta2, 0777, true);
    }
    usleep(10000);
    $carpeta2 = $carpeta."/b";
    if (!file_exists($carpeta2)) {
    	mkdir($carpeta2, 0777, true);
    }
    usleep(10000);
  exit();
?>