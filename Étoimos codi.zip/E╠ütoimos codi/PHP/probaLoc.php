<?php
	$usuari = "poc";
	$directori = "/var/www/vhost/ges-work.com/home/data/etoimos/".$usuari."/";
   	$contents = scandir($directori);
      	if (count($contents) > 0) { 
      		$arrayAssignatures = array(); 
       		for ($i = 0; $i < count($contents); $i++){ 
		 		$assignatures = substr($contents[$i],0);
		 		$arrayNoDirs = array(".","..","...");
				if (in_array($assignatures, $arrayNoDirs)){
		 			//echo "Directori Assignatura: ".$assignatures." el discriminem<br>"; 
		 		}else{
		 			//echo $assignatures."<br>";
		 			$arrayTemes = array();
		 			if (is_dir($directori."/".$assignatures."/")) {
		 				//$arrayTemes[0]=$assignatures;
		 				array_push($arrayTemes,$assignatures);
		 				echo $assignatures." és una assignatura, l'afegim a l'Array<br>";
		 				$contents2 = scandir($directori."/".$assignatures."/");
		 				if (count($contents2) > 0) {  
       						for ($j = 0; $j < count($contents2); $j++){ 
		 						$temes = substr($contents2[$j],0);
		 						if (in_array($temes, $arrayNoDirs)){
		 						
		 						}else{
		 							if (is_dir($directori."/".$assignatures."/".$temes."/")) {
		 								echo $temes." es un tema, l'afegim a l'array de: ".$assignatures."<br>";
		 								//Afegir $Temes a $arrayTemes
		 								array_push($arrayTemes,$temes);
		 							}
		 						}
		 					}
		 				}
		 				echo "Tanquem Assignatura: ".$assignatures."<br>";
		 				echo "Contingut Assignatura: ".$arrayTemes."<br>";
		 				print_r($arrayTemes);
		 				array_push($arrayAssignatures,$arrayTemes);
		 			}
		 		}
		 	}
		 	echo "Probem fer echo arrayAssignatures<br>";
		 	echo json_encode($arrayAssignatures,JSON_FORCE_OBJECT);
		 	//print_r($arrayAssignatures);
		 }
?>