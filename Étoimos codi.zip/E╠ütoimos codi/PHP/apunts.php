<?php
	$gestor = fopen("php://input", "rb");
   	$contenido = stream_get_contents($gestor);
   	$request = json_decode($contenido, true);
   	fclose($gestor);
   	$assignatura = $request['assignatura'];
   	$tema = $request['tema'];
   	$titol = $request['titol'];
   	$referencia = $request['referencia'];
   	$usuari = $request['usuari'];
   	$estat = "NO";
   	echo "1";
   	$variable = 0;
   	while ($variable<60){
   		if (file_exists ("/var/www/vhost/ges-work.com/home/data/etoimos/apuntsProcesant/".$referencia.".jpeg")) { 
   			echo "2";
   			$variable = 60;
        	$homepage = file_get_contents("/var/www/vhost/ges-work.com/home/data/etoimos/apuntsProcesant/".$referencia.".jpeg");
        	$file59 = fopen("/var/www/vhost/ges-work.com/home/data/etoimos/".$usuari."/".$assignatura."/".$tema."/".$titol.".jpeg", "w") or die("Problemas");
    		echo "3";
    		if(fputs($file59,$homepage)){
    			unlink("/var/www/vhost/ges-work.com/home/data/etoimos/apuntsProcesant/".$referencia.".jpeg");
    			$estat = "OK";
    			echo "4";
    		}
    		fclose($file59);
    	}
    	$variable = $variable + 1; 
    	sleep(1);  		
    }      		
   	echo $estat;
?>

   