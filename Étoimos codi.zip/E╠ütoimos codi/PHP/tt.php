<?php
	$gestor = fopen("php://input", "rb");
   	$contenido = stream_get_contents($gestor);
   	$request = json_decode($contenido, true);
   	fclose($gestor);
   	$user = $request['user'];
   	$escan = $request['escan'];
   	echo strlen ($escan);
?>