<?php
	$gestor = fopen("php://input", "rb");
   	$contenido = stream_get_contents($gestor);
   	$request = json_decode($contenido, true);
   	fclose($gestor);
   	$user = $request['usuari'];
   	$dir = "/var/www/vhost/ges-work.com/home/data/etoimos/".$user;
   	if (is_dir($dir)) {
    	$objects = scandir($dir);
    	foreach ($objects as $object) {
      	if ($object != "." && $object != "..") {
        	if (filetype($dir."/".$object) == "dir") 
           		rmdir($dir."/".$object); 
        		else unlink   ($dir."/".$object);
     		 }
    	}
    	reset($objects);
    	rmdir($dir);
    	$host = "qyc278.ges-work.com";
		//$host = "localhost";
		$db = "qyc278";
		$user2 = "qyc279";
		$pass2 = "Etoimosapp3";
		$connection = mysqli_connect($host,$user2,$pass2);
		if(!$connection){
    	   	die ('Conexio fallat: ' . mysqli_connect_error());
   		}
		$dbconnect = mysqli_select_db($connection,$db);
		if(!$dbconnect){
        	die ('No BDD: ' . mysqli_error($connection));
    	}
	    $sql="DELETE FROM Usuarios WHERE Usuari = '$user'"; 
	    //$user2 = "res";
	    //$sql = "DELETE FROM Usuarios WHERE Usuari = '$user2' OR Usuari = '$user'";
    	$retval = mysqli_query( $connection, $sql );
    	if (!$retval){
    		die ('No hem pogut incorporar dates: ' . mysqli_error($connection));
    	}
  	}
   	echo "ok";
   	
?>