<?php

echo bin2hex("H");
echo bin2hex("O");
echo bin2hex("L");
echo bin2hex("A");


$telefon = "191647780411";
$telefon = str_replace("+","",$telefon);
$codi = "Samuel, ya tenemos SpeakApp operativa, puedes invitar a tus amigos";

//$telefon = $prefix.$tel2;
//$codi = $request['codi']." SpeakApp Messenger";
//$valor = file_get_contents('https://api.clickatell.com/http/sendmsg?user=miquelt4&password=JOOTDQaCCFfcHQ&api_id=3600491&to='.urlencode($telefon).'&text='.urlencode($codi));

//$valor = file_get_contents('http://api.clickatell.com/http/sendmsg?user=miquelt&password=IWSHfMDVGSTNQY&api_id=3600116&to='.urlencode($telefon).'&text='.urlencode($codi));
//$valor = file_get_contents('http://api.clickatell.com/http/sendmsg?user=miquelt&password=IWSHfMDVGSTNQY&api_id=3600116&to=0034620293093&text=HOLA_Miquel');
//$valor = file_get_contents('https://sgw01.cm.nl/gateway.ashx?producttoken=a85b3f7e-713c-4d63-836b-2a751e2b9fb9&body='.urlencode($codi).'&to='.urlencode($telefon).'&from=SpeakApp&reference=alta');
$holaMiquel = "Hola Miquel kk  :";
echo urlencode($holaMiquel)."1";
echo $valor;
echo " Fins aqui";
$quatre = 4;
$cinc = 5;
$sis = "hola21";
$set = "hola333";
$vuit = "hola4444";
$nou = "hola55555";
$deu = "hola666666";
$once = "hola7777777";
$dotze = "hola88888888";
$tretze = "hola999999999";
$catorze = "hola1111111111";
$quinze = "hola11111111111";
$setze = "hola111111111111";
$disset = "hola1111111111111";

echo " ".dechex(4);
echo " ".dechex(9);
echo " ".dechex(10);
echo " ".dechex(11);
echo " ".dechex(12);
echo " ".dechex(15);
echo " ".dechex(16);
echo " ".dechex(17);

$leng = strlen($tretze);
$hex = dechex($leng);
if (strlen($hex) == 0) {
	//error
}else{
	if (strlen($hex) == 1) {
		$hex = "000".$hex;
	}else{
		if (strlen($hex) == 2) {
			$hex = "00".$hex;
		}else{
		 	if (strlen($hex) == 3) {
				$hex = "0".$hex;
			}else{
				if (strlen($hex) == 4) {
					//Esta ok
				}else{
					//massa llarg
				}
			}
		}
	}
}

$search  = array('a', 'b', 'c', 'd', 'e', 'f');
$replace = array('A', 'B', 'C', 'D', 'D', 'F');

$hex = str_replace($search, $replace, $hex);

echo "En format Hexadecimal 4 bits: ".$hex;



echo "    ll : ".  explode(".",microtime(true));

$microtime = microtime();
$comps = explode(' ', $microtime);

  // Note: Using a string here to prevent loss of precision
  // in case of "overflow" (PHP converts it to a double)
echo " Comp 1: ".$comps[1];
echo " Comp 1 de 0 a 8: ".substr((string)$comps[1],0,8);
echo " Comp 0: ".$comps[0] * 1000;



$micro_date = microtime();
echo "microdate: ".$micro_date;
echo "microdate formatejada: ".substr((string)$micro_date, 2, 9);


//$data = $entrada[1]." ".$entrada[2];
$data = "20/01/16 13:50:23";

//$novaData = date("Y-m-d H:i:s", strtotime($data));

//$date = date_create_from_format('d/m/y H:i:s', $data);
//strptime('22-09-2008', '%d-%m-%Y');

//echo $date;

$startDate = time();
echo "Valor startDate: ".$startDate;

$fecha = DateTime::createFromFormat('y/m/d H:i:s',$data);
$h = $fecha->format('Y-m-d H:i:s');
echo $h;

$now = DateTime::createFromFormat('U.u', microtime(true));
$f = $now->format("YdmHisu");
$long = strlen($f);
if ($long == 14){
	$f = $f."00000000";
}else{
	if ($long == 15){
		$f = $f."0000000";
	}else{
		if ($long == 16){
			$f = $f."000000";
		}else{
			if ($long == 17){
				$f = $f."00000";
			}else{
				if ($long == 18){
					$f = $f."0000";
				}else{
					if ($long == 19){
						$f = $f."000";
					}else{
						if($long == 20){
							$f = $f."00";
						}else{
							if ($long == 21){
								$f = $f."0";
							}
						}
					}
				}
			}
		}
	}
}

echo " f: ".$f;

$data10 = "2016240119341541655805";
echo " data10: ".$data10;

$dateAra = date_create()->format('YdmHis');
$f = $dateAra."44444444";

echo " Nova f: ".$f;

$micro = round(microtime(true)*1000);
$dateAra = date_create()->format('YdmHis');
echo " Micro: ".$micro;
if (strlen($micro) >=8){
	$micro = substr($micro,0,8);
	echo " Micro retallat: ".$micro;
	$dateAra = $dateAra.$micro;
	echo " Data a enviar: ".$dateAra;
}else{
	$dateAra = $dateAra."41655805";
	echo " DateAra modificada: ".$dateAra;
}

$dataDirecta = date("YdmHis"). substr((string)microtime(), 2, 9);

echo "Data Directa: ".$dataDirecta;

flush();
?>