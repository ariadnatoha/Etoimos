<?php 
 $uploaddir= './upload/';
 $file = basename($_FILES['userfile']['name']);
 chdir('/var/www/vhost/ges-work.com/home/data/etoimos/apuntsProcesant/');
 if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
 	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $file)){
		echo "guardat";
		flush();
 	} 
 }
 exit();
?>